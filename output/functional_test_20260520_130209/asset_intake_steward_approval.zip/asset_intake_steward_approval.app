{
  "description": "",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "AssetIntakeWorkflow",
          "type": "bpmn"
        },
        {
          "key": "assetRequestForm",
          "type": "form"
        },
        {
          "key": "validationForm",
          "type": "form"
        },
        {
          "key": "stewardApprovalForm",
          "type": "form"
        },
        {
          "key": "notificationForm",
          "type": "form"
        }
      ]
    }
  },
  "flowApp": false,
  "groupsAccess": "",
  "icon": "glyphicon-asterisk",
  "key": "AssetIntakeWorkflowApp",
  "name": "Asset Intake and Approval Workflow",
  "paletteDefinitionCategory": "core",
  "theme": "theme-1",
  "url": "",
  "usersAccess": ""
}