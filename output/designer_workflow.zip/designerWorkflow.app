{
  "appName": "",
  "forms": [
    "CreateACollibraGovernedAssetWorkflowStartForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "designerWorkflow.bpmn"
}