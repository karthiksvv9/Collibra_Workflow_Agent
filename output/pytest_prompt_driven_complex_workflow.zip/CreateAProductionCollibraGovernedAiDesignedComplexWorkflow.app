{
  "appName": "Create A Production Collibra Governed Access Workflow From",
  "forms": [
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowAccessRequestForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowRequesterReworkForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowStewardTriageForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowBusinessApprovalForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowComplianceReviewForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowTechnicalRemediationForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflow.bpmn"
}