{
  "description": "",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowAccessRequestForm",
          "type": "form"
        },
        {
          "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowRequesterReworkForm",
          "type": "form"
        },
        {
          "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowStewardTriageForm",
          "type": "form"
        },
        {
          "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowBusinessApprovalForm",
          "type": "form"
        },
        {
          "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowComplianceReviewForm",
          "type": "form"
        },
        {
          "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowTechnicalRemediationForm",
          "type": "form"
        },
        {
          "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflow",
          "type": "bpmn"
        }
      ]
    }
  },
  "flowApp": false,
  "groupsAccess": null,
  "icon": "glyphicon-asterisk",
  "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowApp",
  "name": "Create A Production Collibra Governed Access Workflow From",
  "paletteDefinitionCategory": "core",
  "theme": "theme-1",
  "url": null,
  "usersAccess": null
}