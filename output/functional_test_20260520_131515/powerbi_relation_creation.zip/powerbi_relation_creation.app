{
  "description": "",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "CreateACollibraWorkflowToWorkflow",
          "type": "bpmn"
        },
        {
          "key": "CreateACollibraWorkflowToWorkflowStartForm",
          "type": "form"
        }
      ]
    }
  },
  "flowApp": false,
  "groupsAccess": "",
  "icon": "glyphicon-asterisk",
  "key": "CreateACollibraWorkflowToWorkflowApp",
  "name": "Create A Collibra Workflow To Create A Relation",
  "paletteDefinitionCategory": "core",
  "theme": "theme-1",
  "url": "",
  "usersAccess": ""
}