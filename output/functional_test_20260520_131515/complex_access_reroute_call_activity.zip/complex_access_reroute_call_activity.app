{
  "description": "",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflow",
          "type": "bpmn"
        },
        {
          "key": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowAccessRequestForm",
          "type": "form"
        },
        {
          "key": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowRequesterReworkForm",
          "type": "form"
        },
        {
          "key": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowStewardTriageForm",
          "type": "form"
        },
        {
          "key": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowBusinessApprovalForm",
          "type": "form"
        },
        {
          "key": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowComplianceReviewForm",
          "type": "form"
        },
        {
          "key": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowTechnicalRemediationForm",
          "type": "form"
        }
      ]
    }
  },
  "flowApp": false,
  "groupsAccess": "",
  "icon": "glyphicon-asterisk",
  "key": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowApp",
  "name": "Create A Complex Collibra Governed Data Access Workflow",
  "paletteDefinitionCategory": "core",
  "theme": "theme-1",
  "url": "",
  "usersAccess": ""
}