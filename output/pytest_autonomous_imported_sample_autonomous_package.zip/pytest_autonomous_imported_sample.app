{
  "description": "",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "approvalForm",
          "type": "form"
        },
        {
          "key": "sampleWorkflow",
          "type": "bpmn"
        }
      ]
    }
  },
  "flowApp": false,
  "groupsAccess": null,
  "icon": "glyphicon-asterisk",
  "key": "sampleApp",
  "name": "sampleCollibraApp.zip",
  "paletteDefinitionCategory": "core",
  "theme": "theme-1",
  "url": null,
  "usersAccess": null
}