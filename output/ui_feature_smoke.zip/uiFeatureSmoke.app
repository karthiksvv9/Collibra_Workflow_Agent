{
  "appName": "Smoke",
  "forms": [],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "uiFeatureSmoke.bpmn"
}