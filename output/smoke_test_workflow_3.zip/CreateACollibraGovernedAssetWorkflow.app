{
  "appName": "Create A Collibra Governed Asset Intake Workflow With",
  "forms": [
    "CreateACollibraGovernedAssetWorkflowStartForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "CreateACollibraGovernedAssetWorkflow.bpmn"
}