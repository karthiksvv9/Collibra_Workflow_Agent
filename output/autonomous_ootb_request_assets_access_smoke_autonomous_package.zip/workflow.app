{
  "description": "",
  "elementProperties": {
    "StewardActions": {
      "documentation": "",
      "elementId": "StewardActions",
      "elementName": "Steward actions",
      "elementType": "bpmn:SubProcess",
      "execution": "container",
      "formKey": "StewardActionsInlineForm",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "inlineFormProperties": [
        {
          "expression": null,
          "id": "technicalActionDone",
          "label": "Done",
          "name": "Done",
          "readable": true,
          "required": false,
          "type": "taskButton",
          "value": null,
          "variable": null,
          "writable": true
        }
      ],
      "rawAttributes": {
        "id": "StewardActions",
        "name": "Steward actions"
      },
      "scope": "global"
    },
    "assignRequesterRoleToDataUsage": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "assignRequesterRoleToDataUsage",
      "elementName": "Assign requester role to data usage",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "assignRequesterRoleToDataUsage",
        "name": "Assign requester role to data usage",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "callactivity1": {
      "documentation": "",
      "elementId": "callactivity1",
      "elementName": "request approval",
      "elementType": "bpmn:CallActivity",
      "execution": "service-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "calledElement": "votingSubProcess",
        "flowable:fallbackToDefaultTenant": "true",
        "flowable:inheritVariables": "true",
        "id": "callactivity1",
        "name": "request approval"
      },
      "scope": "asset"
    },
    "checkAllAccessGranted": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "checkAllAccessGranted",
      "elementName": "Check all access granted",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "checkAllAccessGranted",
        "name": "Check all access granted",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "consolidateApprovers": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "consolidateApprovers",
      "elementName": "Consolidate approvers",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "consolidateApprovers",
        "name": "Consolidate approvers",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "endevent1": {
      "documentation": "",
      "elementId": "endevent1",
      "elementName": "End",
      "elementType": "bpmn:EndEvent",
      "execution": "service-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "endevent1",
        "name": "End"
      },
      "scope": "asset"
    },
    "endevent3": {
      "documentation": "",
      "elementId": "endevent3",
      "elementName": "End",
      "elementType": "bpmn:EndEvent",
      "execution": "service-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "endevent3",
        "name": "End"
      },
      "scope": "asset"
    },
    "endevent4": {
      "documentation": "",
      "elementId": "endevent4",
      "elementName": "End",
      "elementType": "bpmn:EndEvent",
      "execution": "service-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "endevent4",
        "name": "End"
      },
      "scope": "asset"
    },
    "endevent5": {
      "documentation": "",
      "elementId": "endevent5",
      "elementName": "End",
      "elementType": "bpmn:EndEvent",
      "execution": "service-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "endevent5",
        "name": "End"
      },
      "scope": "asset"
    },
    "exclusivegateway1": {
      "documentation": "",
      "elementId": "exclusivegateway1",
      "elementName": "Exclusive Gateway",
      "elementType": "bpmn:ExclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "exclusivegateway1",
        "name": "Exclusive Gateway"
      },
      "scope": "global"
    },
    "exclusivegateway2": {
      "documentation": "",
      "elementId": "exclusivegateway2",
      "elementName": "Exclusive Gateway",
      "elementType": "bpmn:ExclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "exclusivegateway2",
        "name": "Exclusive Gateway"
      },
      "scope": "global"
    },
    "exclusivegateway5": {
      "documentation": "",
      "elementId": "exclusivegateway5",
      "elementName": "Exclusive Gateway",
      "elementType": "bpmn:ExclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "exclusivegateway5",
        "name": "Exclusive Gateway"
      },
      "scope": "global"
    },
    "exclusivegateway6": {
      "documentation": "",
      "elementId": "exclusivegateway6",
      "elementName": "Exclusive Gateway",
      "elementType": "bpmn:ExclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "exclusivegateway6",
        "name": "Exclusive Gateway"
      },
      "scope": "global"
    },
    "exclusivegateway7": {
      "documentation": "",
      "elementId": "exclusivegateway7",
      "elementName": "Exclusive Gateway",
      "elementType": "bpmn:ExclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "exclusivegateway7",
        "name": "Exclusive Gateway"
      },
      "scope": "global"
    },
    "findReportApprovers": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "findReportApprovers",
      "elementName": "Find approvers",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "findReportApprovers",
        "name": "Find approvers",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "flow1": {
      "condition": "",
      "documentation": "",
      "elementId": "flow1",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow1",
        "sourceRef": "startevent1",
        "targetRef": "generateDataUsageName"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow12": {
      "condition": "${validDataElements}",
      "documentation": "",
      "elementId": "flow12",
      "elementName": "valid",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow12",
        "name": "valid",
        "sourceRef": "exclusivegateway2",
        "targetRef": "servicetask1"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow13": {
      "condition": "${!validDataElements}",
      "documentation": "",
      "elementId": "flow13",
      "elementName": "invalid",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow13",
        "name": "invalid",
        "sourceRef": "exclusivegateway2",
        "targetRef": "handleInvalidDataElement"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow15": {
      "condition": "",
      "documentation": "",
      "elementId": "flow15",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow15",
        "sourceRef": "servicetask9",
        "targetRef": "endevent3"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow16": {
      "condition": "",
      "documentation": "",
      "elementId": "flow16",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow16",
        "sourceRef": "servicetask8",
        "targetRef": "StewardActions"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow17": {
      "condition": "",
      "documentation": "",
      "elementId": "flow17",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow17",
        "sourceRef": "servicetask10",
        "targetRef": "servicetask9"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow20": {
      "condition": "",
      "documentation": "",
      "elementId": "flow20",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow20",
        "sourceRef": "startevent2",
        "targetRef": "usertask1"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow21": {
      "condition": "",
      "documentation": "",
      "elementId": "flow21",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow21",
        "sourceRef": "usertask1",
        "targetRef": "checkAllAccessGranted"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow22": {
      "condition": "",
      "documentation": "",
      "elementId": "flow22",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow22",
        "sourceRef": "checkAllAccessGranted",
        "targetRef": "endevent4"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow23": {
      "condition": "",
      "documentation": "",
      "elementId": "flow23",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow23",
        "sourceRef": "generateDataUsageName",
        "targetRef": "initDataUsageRequest"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow3": {
      "condition": "",
      "documentation": "",
      "elementId": "flow3",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow3",
        "sourceRef": "callactivity1",
        "targetRef": "exclusivegateway1"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow33": {
      "condition": "",
      "documentation": "",
      "elementId": "flow33",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow33",
        "sourceRef": "servicetask2",
        "targetRef": "inclusivegateway3"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow34": {
      "condition": "${containsDataSets}",
      "documentation": "",
      "elementId": "flow34",
      "elementName": "data sets",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow34",
        "name": "data sets",
        "sourceRef": "inclusivegateway3",
        "targetRef": "servicetask8"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow37": {
      "condition": "",
      "documentation": "",
      "elementId": "flow37",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow37",
        "sourceRef": "StewardActions",
        "targetRef": "scripttask9"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow39": {
      "condition": "",
      "documentation": "",
      "elementId": "flow39",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow39",
        "sourceRef": "initDataUsageRequest",
        "targetRef": "assignRequesterRoleToDataUsage"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow42": {
      "condition": "",
      "documentation": "",
      "elementId": "flow42",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow42",
        "sourceRef": "validateDataElements",
        "targetRef": "exclusivegateway2"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow44": {
      "condition": "",
      "documentation": "",
      "elementId": "flow44",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow44",
        "sourceRef": "handleInvalidDataElement",
        "targetRef": "terminateendevent1"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow45": {
      "condition": "",
      "documentation": "",
      "elementId": "flow45",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow45",
        "sourceRef": "identifyReportsAndDataSets",
        "targetRef": "inclusivegateway1"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow46": {
      "condition": "${containsDataSets}",
      "documentation": "",
      "elementId": "flow46",
      "elementName": "data sets",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow46",
        "name": "data sets",
        "sourceRef": "inclusivegateway1",
        "targetRef": "validateDataElements"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow47": {
      "condition": "${containsReports}",
      "documentation": "",
      "elementId": "flow47",
      "elementName": "reports",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow47",
        "name": "reports",
        "sourceRef": "inclusivegateway1",
        "targetRef": "validateReports"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow48": {
      "condition": "",
      "documentation": "",
      "elementId": "flow48",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow48",
        "sourceRef": "servicetask1",
        "targetRef": "inclusivegateway2"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow49": {
      "condition": "",
      "documentation": "",
      "elementId": "flow49",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow49",
        "sourceRef": "findReportApprovers",
        "targetRef": "inclusivegateway2"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow5": {
      "condition": "${!votingResult}",
      "documentation": "",
      "elementId": "flow5",
      "elementName": "rejected",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow5",
        "name": "rejected",
        "sourceRef": "exclusivegateway1",
        "targetRef": "servicetask10"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow51": {
      "condition": "",
      "documentation": "",
      "elementId": "flow51",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow51",
        "sourceRef": "validateReports",
        "targetRef": "exclusivegateway5"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow52": {
      "condition": "${validReports}",
      "documentation": "",
      "elementId": "flow52",
      "elementName": "valid",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow52",
        "name": "valid",
        "sourceRef": "exclusivegateway5",
        "targetRef": "findReportApprovers"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow53": {
      "condition": "",
      "documentation": "",
      "elementId": "flow53",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow53",
        "sourceRef": "inclusivegateway2",
        "targetRef": "consolidateApprovers"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow54": {
      "condition": "${!validReports}",
      "documentation": "",
      "elementId": "flow54",
      "elementName": "invalid",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow54",
        "name": "invalid",
        "sourceRef": "exclusivegateway5",
        "targetRef": "handleInvalidReports"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow55": {
      "condition": "",
      "documentation": "",
      "elementId": "flow55",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow55",
        "sourceRef": "handleInvalidReports",
        "targetRef": "terminateendevent2"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow56": {
      "condition": "",
      "documentation": "",
      "elementId": "flow56",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow56",
        "sourceRef": "servicetask11",
        "targetRef": "scripttask7"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow57": {
      "condition": "",
      "documentation": "",
      "elementId": "flow57",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow57",
        "sourceRef": "scripttask7",
        "targetRef": "subprocess1"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow58": {
      "condition": "",
      "documentation": "",
      "elementId": "flow58",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow58",
        "sourceRef": "startevent3",
        "targetRef": "scripttask8"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow59": {
      "condition": "",
      "documentation": "",
      "elementId": "flow59",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow59",
        "sourceRef": "scripttask8",
        "targetRef": "exclusivegateway6"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow6": {
      "condition": "${votingResult}",
      "documentation": "",
      "elementId": "flow6",
      "elementName": "accepted",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow6",
        "name": "accepted",
        "sourceRef": "exclusivegateway1",
        "targetRef": "servicetask2"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow60": {
      "condition": "${!dataAnalystRoleAssigned}",
      "documentation": "",
      "elementId": "flow60",
      "elementName": "not assigned",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow60",
        "name": "not assigned",
        "sourceRef": "exclusivegateway6",
        "targetRef": "servicetask15"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow61": {
      "condition": "",
      "documentation": "",
      "elementId": "flow61",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow61",
        "sourceRef": "servicetask15",
        "targetRef": "endevent5"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow62": {
      "condition": "${dataAnalystRoleAssigned}",
      "documentation": "",
      "elementId": "flow62",
      "elementName": "assigned",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow62",
        "name": "assigned",
        "sourceRef": "exclusivegateway6",
        "targetRef": "endevent5"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow63": {
      "condition": "",
      "documentation": "",
      "elementId": "flow63",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow63",
        "sourceRef": "subprocess1",
        "targetRef": "servicetask4"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow64": {
      "condition": "",
      "documentation": "",
      "elementId": "flow64",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow64",
        "sourceRef": "consolidateApprovers",
        "targetRef": "markAsApprovalPending"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow65": {
      "condition": "",
      "documentation": "",
      "elementId": "flow65",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow65",
        "sourceRef": "markAsApprovalPending",
        "targetRef": "callactivity1"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow66": {
      "condition": "${containsReports}",
      "documentation": "",
      "elementId": "flow66",
      "elementName": "reports",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow66",
        "name": "reports",
        "sourceRef": "inclusivegateway3",
        "targetRef": "inclusivegateway4"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow67": {
      "condition": "",
      "documentation": "",
      "elementId": "flow67",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow67",
        "sourceRef": "scripttask9",
        "targetRef": "inclusivegateway4"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow68": {
      "condition": "${dataSetsAccessGranted}",
      "documentation": "",
      "elementId": "flow68",
      "elementName": "all data sets access granted",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow68",
        "name": "all data sets access granted",
        "sourceRef": "inclusivegateway4",
        "targetRef": "servicetask11"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow69": {
      "condition": "",
      "documentation": "",
      "elementId": "flow69",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow69",
        "sourceRef": "assignRequesterRoleToDataUsage",
        "targetRef": "scripttask10"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow72": {
      "condition": "",
      "documentation": "",
      "elementId": "flow72",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow72",
        "sourceRef": "usertask2",
        "targetRef": "scripttask11"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow73": {
      "condition": "",
      "documentation": "",
      "elementId": "flow73",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow73",
        "sourceRef": "scripttask11",
        "targetRef": "identifyReportsAndDataSets"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow74": {
      "condition": "",
      "documentation": "",
      "elementId": "flow74",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow74",
        "sourceRef": "scripttask10",
        "targetRef": "exclusivegateway7"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow75": {
      "condition": "${isPurpose}",
      "documentation": "",
      "elementId": "flow75",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow75",
        "sourceRef": "exclusivegateway7",
        "targetRef": "usertask2"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow76": {
      "condition": "${!isPurpose}",
      "documentation": "",
      "elementId": "flow76",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "conditional",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow76",
        "sourceRef": "exclusivegateway7",
        "targetRef": "identifyReportsAndDataSets"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "flow9": {
      "condition": "",
      "documentation": "",
      "elementId": "flow9",
      "elementName": "",
      "elementType": "bpmn:SequenceFlow",
      "execution": "gateway-condition",
      "flowType": "normal",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "flow9",
        "sourceRef": "servicetask4",
        "targetRef": "endevent1"
      },
      "scope": "global",
      "skipExpression": ""
    },
    "generateDataUsageName": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "generateDataUsageName",
      "elementName": "Generate data usage name",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "generateDataUsageName",
        "name": "Generate data usage name",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "handleInvalidDataElement": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "handleInvalidDataElement",
      "elementName": "Handle Invalid Data Element",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "handleInvalidDataElement",
        "name": "Handle Invalid Data Element",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "handleInvalidReports": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "handleInvalidReports",
      "elementName": "HandleInvalidReports",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "handleInvalidReports",
        "name": "HandleInvalidReports",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "identifyReportsAndDataSets": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "identifyReportsAndDataSets",
      "elementName": "Identify reports and data sets",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "identifyReportsAndDataSets",
        "name": "Identify reports and data sets",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "inclusivegateway1": {
      "documentation": "",
      "elementId": "inclusivegateway1",
      "elementName": "Inclusive Gateway",
      "elementType": "bpmn:InclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "inclusivegateway1",
        "name": "Inclusive Gateway"
      },
      "scope": "global"
    },
    "inclusivegateway2": {
      "documentation": "",
      "elementId": "inclusivegateway2",
      "elementName": "Inclusive Gateway",
      "elementType": "bpmn:InclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "inclusivegateway2",
        "name": "Inclusive Gateway"
      },
      "scope": "global"
    },
    "inclusivegateway3": {
      "documentation": "",
      "elementId": "inclusivegateway3",
      "elementName": "Inclusive Gateway",
      "elementType": "bpmn:InclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "inclusivegateway3",
        "name": "Inclusive Gateway"
      },
      "scope": "global"
    },
    "inclusivegateway4": {
      "documentation": "",
      "elementId": "inclusivegateway4",
      "elementName": "Inclusive Gateway",
      "elementType": "bpmn:InclusiveGateway",
      "execution": "gateway-condition",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "inclusivegateway4",
        "name": "Inclusive Gateway"
      },
      "scope": "global"
    },
    "initDataUsageRequest": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "initDataUsageRequest",
      "elementName": "Init data usage request",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "initDataUsageRequest",
        "name": "Init data usage request",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "lane1": {
      "documentation": "",
      "elementId": "lane1",
      "elementName": "Requester",
      "elementType": "bpmn:Lane",
      "execution": "container",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "lane1",
        "name": "Requester"
      },
      "scope": "global"
    },
    "lane2": {
      "documentation": "",
      "elementId": "lane2",
      "elementName": "Approver",
      "elementType": "bpmn:Lane",
      "execution": "container",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "lane2",
        "name": "Approver"
      },
      "scope": "global"
    },
    "lane3": {
      "documentation": "",
      "elementId": "lane3",
      "elementName": "Technical steward/ System",
      "elementType": "bpmn:Lane",
      "execution": "container",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "lane3",
        "name": "Technical steward/ System"
      },
      "scope": "global"
    },
    "markAsApprovalPending": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "markAsApprovalPending",
      "elementName": "Mark as approval pending",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "markAsApprovalPending",
        "name": "Mark as approval pending",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "pool1": {
      "documentation": "",
      "elementId": "pool1",
      "elementName": "Request Assets Access",
      "elementType": "bpmn:Participant",
      "execution": "container",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "pool1",
        "name": "Request Assets Access",
        "processRef": "RequestDataSetsAccess"
      },
      "scope": "global"
    },
    "scripttask10": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "scripttask10",
      "elementName": "Check if Purpose asset type exists",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "scripttask10",
        "name": "Check if Purpose asset type exists",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "scripttask11": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "scripttask11",
      "elementName": "Add Purpose",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "scripttask11",
        "name": "Add Purpose",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "scripttask7": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "scripttask7",
      "elementName": "Find Assets that need to have Data Analyst role assigned",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "scripttask7",
        "name": "Find Assets that need to have Data Analyst role assigned",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "scripttask8": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "scripttask8",
      "elementName": "Check if Data Analyst role is already assigned",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "scripttask8",
        "name": "Check if Data Analyst role is already assigned",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "scripttask9": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "scripttask9",
      "elementName": "Data Sets Access Granted",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "scripttask9",
        "name": "Data Sets Access Granted",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "servicetask1": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "servicetask1",
      "elementName": "Init data usage request",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "servicetask1",
        "name": "Init data usage request",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "servicetask10": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "servicetask10",
      "elementName": "Mark as refused",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "servicetask10",
        "name": "Mark as refused",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "servicetask11": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "servicetask11",
      "elementName": "Mark as access granted",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "servicetask11",
        "name": "Mark as access granted",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "servicetask15": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "servicetask15",
      "elementName": "Assign Data Analyst Level 2 role on impacted data element",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "servicetask15",
        "name": "Assign Data Analyst Level 2 role on impacted data element",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "servicetask2": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "servicetask2",
      "elementName": "Mark as accepted",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "servicetask2",
        "name": "Mark as accepted",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "servicetask4": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "servicetask4",
      "elementName": "notify requester",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "servicetask4",
        "name": "notify requester",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "servicetask8": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "servicetask8",
      "elementName": "Identify technical stewards",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "servicetask8",
        "name": "Identify technical stewards",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "servicetask9": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "servicetask9",
      "elementName": "notify rejected approval",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "servicetask9",
        "name": "notify rejected approval",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "startevent1": {
      "documentation": "",
      "elementId": "startevent1",
      "elementName": "Start",
      "elementType": "bpmn:StartEvent",
      "execution": "service-groovy",
      "formFieldValidation": "false",
      "formKey": "requestAssetsAccessStartForm",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "inlineFormProperties": [
        {
          "expression": null,
          "id": "sendVotingActionEmails",
          "label": "Send an action email to users that are required to approve data usage",
          "name": "Send an action email to users that are required to approve data usage",
          "readable": false,
          "required": true,
          "type": "boolean",
          "value": "true",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "voteWarningTimeDuration",
          "label": "Please enter time duration before a voting reminder is send",
          "name": "Please enter time duration before a voting reminder is send",
          "readable": false,
          "required": false,
          "type": "string",
          "value": "B5D",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "voteTimeoutDuration",
          "label": "Timeout before voting process is forced to continue",
          "name": "Timeout before voting process is forced to continue",
          "readable": false,
          "required": false,
          "type": "string",
          "value": "P1M",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "voteCompletionPercentage",
          "label": "Percentage required to vote before completion",
          "name": "Percentage required to vote before completion",
          "readable": false,
          "required": false,
          "type": "long",
          "value": "100",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "dataUsageName",
          "label": "Please give your data usage request a name",
          "name": "Please give your data usage request a name",
          "readable": false,
          "required": false,
          "type": "string",
          "value": "data usage name",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "dataUsagePurposeRelationTypeUuid",
          "label": "Data Usage Purpose Relation Type UUID",
          "name": "Data Usage Purpose Relation Type UUID",
          "readable": false,
          "required": false,
          "type": "string",
          "value": "c0e00000-0000-0000-0000-000000007434",
          "variable": null,
          "writable": true
        }
      ],
      "rawAttributes": {
        "flowable:formFieldValidation": "false",
        "flowable:formKey": "requestAssetsAccessStartForm",
        "flowable:initiator": "requester",
        "id": "startevent1",
        "name": "Start"
      },
      "scope": "asset"
    },
    "startevent2": {
      "documentation": "",
      "elementId": "startevent2",
      "elementName": "Start",
      "elementType": "bpmn:StartEvent",
      "execution": "service-groovy",
      "formFieldValidation": "false",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:formFieldValidation": "false",
        "id": "startevent2",
        "name": "Start"
      },
      "scope": "asset"
    },
    "startevent3": {
      "documentation": "",
      "elementId": "startevent3",
      "elementName": "Start",
      "elementType": "bpmn:StartEvent",
      "execution": "service-groovy",
      "formFieldValidation": "false",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:formFieldValidation": "false",
        "id": "startevent3",
        "name": "Start"
      },
      "scope": "asset"
    },
    "subprocess1": {
      "documentation": "",
      "elementId": "subprocess1",
      "elementName": "Data elements role assignment",
      "elementType": "bpmn:SubProcess",
      "execution": "container",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "subprocess1",
        "name": "Data elements role assignment"
      },
      "scope": "global"
    },
    "terminateendevent1": {
      "documentation": "",
      "elementId": "terminateendevent1",
      "elementName": "TerminateEndEvent",
      "elementType": "bpmn:EndEvent",
      "execution": "service-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "terminateendevent1",
        "name": "TerminateEndEvent"
      },
      "scope": "asset"
    },
    "terminateendevent2": {
      "documentation": "",
      "elementId": "terminateendevent2",
      "elementName": "TerminateEndEvent",
      "elementType": "bpmn:EndEvent",
      "execution": "service-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "id": "terminateendevent2",
        "name": "TerminateEndEvent"
      },
      "scope": "asset"
    },
    "usertask1": {
      "candidateUsers": "user(${techSteward})",
      "documentation": "A new data usage request has been approved. Please take action to grant the requester\n                    access to the related data.",
      "elementId": "usertask1",
      "elementName": "Request stewards action",
      "elementType": "bpmn:UserTask",
      "execution": "user-form",
      "formFieldValidation": "false",
      "formKey": "usertask1InlineForm",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "inlineFormProperties": [
        {
          "expression": null,
          "id": "technicalActionDone",
          "label": "Done",
          "name": "Done",
          "readable": true,
          "required": false,
          "type": "taskButton",
          "value": null,
          "variable": null,
          "writable": true
        }
      ],
      "rawAttributes": {
        "flowable:candidateUsers": "user(${techSteward})",
        "flowable:formFieldValidation": "false",
        "id": "usertask1",
        "name": "Request stewards action"
      },
      "scope": "asset"
    },
    "usertask2": {
      "candidateUsers": "user(${requester})",
      "documentation": "",
      "elementId": "usertask2",
      "elementName": "Add Purpose to the Data Usage",
      "elementType": "bpmn:UserTask",
      "execution": "user-form",
      "formFieldValidation": "false",
      "formKey": "requestAssetsAccessAddPurposeForm",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:candidateUsers": "user(${requester})",
        "flowable:formFieldValidation": "false",
        "flowable:formKey": "requestAssetsAccessAddPurposeForm",
        "id": "usertask2",
        "name": "Add Purpose to the Data Usage"
      },
      "scope": "asset"
    },
    "validateDataElements": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "validateDataElements",
      "elementName": "Validate data elements",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "validateDataElements",
        "name": "Validate data elements",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    },
    "validateReports": {
      "autoStoreVariables": "false",
      "documentation": "",
      "elementId": "validateReports",
      "elementName": "Validate reports",
      "elementType": "bpmn:ScriptTask",
      "execution": "script-groovy",
      "importedFrom": "RequestDataSetsAccess.bpmn",
      "rawAttributes": {
        "flowable:autoStoreVariables": "false",
        "id": "validateReports",
        "name": "Validate reports",
        "scriptFormat": "groovy"
      },
      "scope": "asset",
      "scriptFormat": "groovy"
    }
  },
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "requestAssetsAccessStartForm",
          "type": "form"
        },
        {
          "key": "requestAssetsAccessAddPurposeForm",
          "type": "form"
        },
        {
          "key": "RequestDataSetsAccess",
          "type": "bpmn"
        }
      ]
    }
  },
  "flowApp": false,
  "forms": {
    "StewardActionsInlineForm": {
      "description": "Inline flowable:formProperty definitions extracted from BPMN.",
      "fields": [
        {
          "expression": null,
          "id": "technicalActionDone",
          "label": "Done",
          "name": "Done",
          "readable": true,
          "required": false,
          "type": "taskButton",
          "value": null,
          "variable": null,
          "writable": true
        }
      ],
      "key": "StewardActionsInlineForm",
      "metadata": {
        "key": "StewardActionsInlineForm",
        "name": "Steward actions Inline Form"
      },
      "modelType": "inline-form",
      "name": "Steward actions Inline Form",
      "outcomes": [
        {
          "expression": null,
          "id": "technicalActionDone",
          "label": "Done",
          "name": "Done",
          "readable": true,
          "required": false,
          "type": "taskButton",
          "value": null,
          "variable": null,
          "writable": true
        }
      ],
      "ownerElementId": "StewardActions",
      "rows": [],
      "source": "RequestDataSetsAccess.bpmn"
    },
    "requestAssetsAccessAddPurposeForm": {
      "description": "",
      "fields": [
        {
          "column": 0,
          "enabled": true,
          "extraSettings": {
            "assetTypeIds": [
              "c0e00000-0000-0000-0000-000000039021"
            ],
            "assetTypeInheritance": true,
            "proposedValues": [],
            "proposedValuesOnly": false,
            "storage": "Id"
          },
          "id": "collibra-asset1",
          "label": "Purpose",
          "name": "Purpose",
          "readable": true,
          "required": true,
          "row": 0,
          "size": 12,
          "stencilId": "collibra-asset",
          "stencilSuperIds": [
            "base-component",
            "Component"
          ],
          "type": "asset",
          "value": "{{purpose}}",
          "visible": true,
          "writable": true
        }
      ],
      "key": "requestAssetsAccessAddPurposeForm",
      "metadata": {
        "description": "",
        "flowableDesignVersion": 3110,
        "key": "requestAssetsAccessAddPurposeForm",
        "modelType": "form",
        "name": "requestAssetsAccessAddPurposeForm",
        "palette": "flowable-core-form-palette",
        "version": "1"
      },
      "modelType": "form",
      "name": "requestAssetsAccessAddPurposeForm",
      "outcomes": [],
      "palette": "flowable-core-form-palette",
      "raw": {
        "metadata": {
          "description": "",
          "flowableDesignVersion": 3110,
          "key": "requestAssetsAccessAddPurposeForm",
          "modelType": "form",
          "name": "requestAssetsAccessAddPurposeForm",
          "palette": "flowable-core-form-palette",
          "version": "1"
        },
        "rows": [
          {
            "cols": [
              {
                "designInfo": {
                  "stencilId": "collibra-asset",
                  "stencilSuperIds": [
                    "base-component",
                    "Component"
                  ]
                },
                "enabled": true,
                "extraSettings": {
                  "assetTypeIds": [
                    "c0e00000-0000-0000-0000-000000039021"
                  ],
                  "assetTypeInheritance": true,
                  "proposedValues": [],
                  "proposedValuesOnly": false,
                  "storage": "Id"
                },
                "id": "collibra-asset1",
                "ignore": false,
                "isRequired": true,
                "label": "Purpose",
                "size": 12,
                "type": "asset",
                "value": "{{purpose}}",
                "visible": true
              }
            ]
          }
        ]
      },
      "rows": [
        {
          "cols": [
            {
              "designInfo": {
                "stencilId": "collibra-asset",
                "stencilSuperIds": [
                  "base-component",
                  "Component"
                ]
              },
              "enabled": true,
              "extraSettings": {
                "assetTypeIds": [
                  "c0e00000-0000-0000-0000-000000039021"
                ],
                "assetTypeInheritance": true,
                "proposedValues": [],
                "proposedValuesOnly": false,
                "storage": "Id"
              },
              "id": "collibra-asset1",
              "ignore": false,
              "isRequired": true,
              "label": "Purpose",
              "size": 12,
              "type": "asset",
              "value": "{{purpose}}",
              "visible": true
            }
          ]
        }
      ],
      "source": "form-requestAssetsAccessAddPurposeForm.form",
      "version": "1"
    },
    "requestAssetsAccessStartForm": {
      "description": "",
      "fields": [
        {
          "column": 0,
          "enabled": true,
          "extraSettings": {
            "minRows": 1,
            "textFormat": "html",
            "useSpellCheck": false
          },
          "id": "usageRequestReason",
          "label": "Why do you need access to this data?",
          "name": "Why do you need access to this data?",
          "readable": true,
          "required": true,
          "row": 0,
          "size": 12,
          "stencilId": "cloud-rich-text",
          "stencilSuperIds": [
            "cloud-rich-text",
            "Component"
          ],
          "type": "richText",
          "value": "{{usageRequestReason}}",
          "visible": true,
          "writable": true
        },
        {
          "column": 0,
          "enabled": true,
          "extraSettings": {
            "calendarStartDay": "monday",
            "enableTime": false,
            "storeWithoutTime": true
          },
          "id": "startTime",
          "label": "I need this data by...",
          "name": "I need this data by...",
          "readable": true,
          "required": true,
          "row": 1,
          "size": 12,
          "stencilId": "cloud-date",
          "stencilSuperIds": [
            "cloud-date",
            "Component"
          ],
          "type": "date",
          "value": "{{startTime}}",
          "visible": true,
          "writable": true
        },
        {
          "column": 0,
          "enabled": true,
          "extraSettings": {
            "calendarStartDay": "monday",
            "enableTime": false,
            "storeWithoutTime": true
          },
          "id": "endTime",
          "label": "and will use it until...",
          "name": "and will use it until...",
          "readable": true,
          "required": true,
          "row": 2,
          "size": 12,
          "stencilId": "cloud-date",
          "stencilSuperIds": [
            "cloud-date",
            "Component"
          ],
          "type": "date",
          "value": "{{endTime}}",
          "visible": true,
          "writable": true
        }
      ],
      "key": "requestAssetsAccessStartForm",
      "metadata": {
        "description": "",
        "flowableDesignVersion": 3110,
        "key": "requestAssetsAccessStartForm",
        "modelType": "form",
        "name": "requestAssetsAccessStartForm",
        "palette": "flowable-core-form-palette",
        "version": "1"
      },
      "modelType": "form",
      "name": "requestAssetsAccessStartForm",
      "outcomes": [],
      "palette": "flowable-core-form-palette",
      "raw": {
        "metadata": {
          "description": "",
          "flowableDesignVersion": 3110,
          "key": "requestAssetsAccessStartForm",
          "modelType": "form",
          "name": "requestAssetsAccessStartForm",
          "palette": "flowable-core-form-palette",
          "version": "1"
        },
        "rows": [
          {
            "cols": [
              {
                "designInfo": {
                  "stencilId": "cloud-rich-text",
                  "stencilSuperIds": [
                    "cloud-rich-text",
                    "Component"
                  ]
                },
                "enabled": true,
                "extraSettings": {
                  "minRows": 1,
                  "textFormat": "html",
                  "useSpellCheck": false
                },
                "id": "usageRequestReason",
                "ignore": false,
                "isRequired": true,
                "label": "Why do you need access to this data?",
                "size": 12,
                "type": "richText",
                "value": "{{usageRequestReason}}",
                "visible": true
              }
            ]
          },
          {
            "cols": [
              {
                "designInfo": {
                  "stencilId": "cloud-date",
                  "stencilSuperIds": [
                    "cloud-date",
                    "Component"
                  ]
                },
                "enabled": true,
                "extraSettings": {
                  "calendarStartDay": "monday",
                  "enableTime": false,
                  "storeWithoutTime": true
                },
                "id": "startTime",
                "ignore": false,
                "isRequired": true,
                "label": "I need this data by...",
                "size": 12,
                "type": "date",
                "value": "{{startTime}}",
                "visible": true
              }
            ]
          },
          {
            "cols": [
              {
                "designInfo": {
                  "stencilId": "cloud-date",
                  "stencilSuperIds": [
                    "cloud-date",
                    "Component"
                  ]
                },
                "enabled": true,
                "extraSettings": {
                  "calendarStartDay": "monday",
                  "enableTime": false,
                  "storeWithoutTime": true
                },
                "id": "endTime",
                "ignore": false,
                "isRequired": true,
                "label": "and will use it until...",
                "size": 12,
                "type": "date",
                "value": "{{endTime}}",
                "visible": true
              }
            ]
          }
        ]
      },
      "rows": [
        {
          "cols": [
            {
              "designInfo": {
                "stencilId": "cloud-rich-text",
                "stencilSuperIds": [
                  "cloud-rich-text",
                  "Component"
                ]
              },
              "enabled": true,
              "extraSettings": {
                "minRows": 1,
                "textFormat": "html",
                "useSpellCheck": false
              },
              "id": "usageRequestReason",
              "ignore": false,
              "isRequired": true,
              "label": "Why do you need access to this data?",
              "size": 12,
              "type": "richText",
              "value": "{{usageRequestReason}}",
              "visible": true
            }
          ]
        },
        {
          "cols": [
            {
              "designInfo": {
                "stencilId": "cloud-date",
                "stencilSuperIds": [
                  "cloud-date",
                  "Component"
                ]
              },
              "enabled": true,
              "extraSettings": {
                "calendarStartDay": "monday",
                "enableTime": false,
                "storeWithoutTime": true
              },
              "id": "startTime",
              "ignore": false,
              "isRequired": true,
              "label": "I need this data by...",
              "size": 12,
              "type": "date",
              "value": "{{startTime}}",
              "visible": true
            }
          ]
        },
        {
          "cols": [
            {
              "designInfo": {
                "stencilId": "cloud-date",
                "stencilSuperIds": [
                  "cloud-date",
                  "Component"
                ]
              },
              "enabled": true,
              "extraSettings": {
                "calendarStartDay": "monday",
                "enableTime": false,
                "storeWithoutTime": true
              },
              "id": "endTime",
              "ignore": false,
              "isRequired": true,
              "label": "and will use it until...",
              "size": 12,
              "type": "date",
              "value": "{{endTime}}",
              "visible": true
            }
          ]
        }
      ],
      "source": "form-requestAssetsAccessStartForm.form",
      "version": "1"
    },
    "startevent1InlineForm": {
      "description": "Inline flowable:formProperty definitions extracted from BPMN.",
      "fields": [
        {
          "expression": null,
          "id": "sendVotingActionEmails",
          "label": "Send an action email to users that are required to approve data usage",
          "name": "Send an action email to users that are required to approve data usage",
          "readable": false,
          "required": true,
          "type": "boolean",
          "value": "true",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "voteWarningTimeDuration",
          "label": "Please enter time duration before a voting reminder is send",
          "name": "Please enter time duration before a voting reminder is send",
          "readable": false,
          "required": false,
          "type": "string",
          "value": "B5D",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "voteTimeoutDuration",
          "label": "Timeout before voting process is forced to continue",
          "name": "Timeout before voting process is forced to continue",
          "readable": false,
          "required": false,
          "type": "string",
          "value": "P1M",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "voteCompletionPercentage",
          "label": "Percentage required to vote before completion",
          "name": "Percentage required to vote before completion",
          "readable": false,
          "required": false,
          "type": "long",
          "value": "100",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "dataUsageName",
          "label": "Please give your data usage request a name",
          "name": "Please give your data usage request a name",
          "readable": false,
          "required": false,
          "type": "string",
          "value": "data usage name",
          "variable": null,
          "writable": true
        },
        {
          "expression": null,
          "id": "dataUsagePurposeRelationTypeUuid",
          "label": "Data Usage Purpose Relation Type UUID",
          "name": "Data Usage Purpose Relation Type UUID",
          "readable": false,
          "required": false,
          "type": "string",
          "value": "c0e00000-0000-0000-0000-000000007434",
          "variable": null,
          "writable": true
        }
      ],
      "key": "startevent1InlineForm",
      "metadata": {
        "key": "startevent1InlineForm",
        "name": "Start Inline Form"
      },
      "modelType": "inline-form",
      "name": "Start Inline Form",
      "outcomes": [],
      "ownerElementId": "startevent1",
      "rows": [],
      "source": "RequestDataSetsAccess.bpmn"
    },
    "usertask1InlineForm": {
      "description": "Inline flowable:formProperty definitions extracted from BPMN.",
      "fields": [
        {
          "expression": null,
          "id": "technicalActionDone",
          "label": "Done",
          "name": "Done",
          "readable": true,
          "required": false,
          "type": "taskButton",
          "value": null,
          "variable": null,
          "writable": true
        }
      ],
      "key": "usertask1InlineForm",
      "metadata": {
        "key": "usertask1InlineForm",
        "name": "Request stewards action Inline Form"
      },
      "modelType": "inline-form",
      "name": "Request stewards action Inline Form",
      "outcomes": [
        {
          "expression": null,
          "id": "technicalActionDone",
          "label": "Done",
          "name": "Done",
          "readable": true,
          "required": false,
          "type": "taskButton",
          "value": null,
          "variable": null,
          "writable": true
        }
      ],
      "ownerElementId": "usertask1",
      "rows": [],
      "source": "RequestDataSetsAccess.bpmn"
    }
  },
  "groupsAccess": null,
  "icon": "glyphicon-asterisk",
  "importDiagnostics": {
    "embeddedScripts": 25,
    "formReferences": 4,
    "inlineForms": 3,
    "missingForms": [],
    "scriptTasks": 25,
    "sequenceFlows": 49,
    "sourceBpmn": "RequestDataSetsAccess.bpmn",
    "userTasks": 2
  },
  "key": "requestAssetsAccessApp",
  "metadata": {
    "format": "DSC_SIDE_CAR_APP_V1",
    "name": "RequestAssetsAccessApp.zip"
  },
  "name": "RequestAssetsAccessApp",
  "paletteDefinitionCategory": "core",
  "scripts": {
    "assignRequesterRoleToDataUsage": {
      "elementId": "assignRequesterRoleToDataUsage",
      "elementName": "Assign requester role to data usage",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.core.api.dto.instance.responsibility.AddResponsibilityRequest\nimport com.collibra.dgc.core.api.dto.user.FindUsersRequest\n\nREQUESTER_ROLE_ID = string2Uuid(\"00000000-0000-0000-0000-000000005033\")\n\ndef user = userApi.findUsers(FindUsersRequest.builder()\n        .name(requester)\n        .build())\n        .getResults()\n        .first()\n\nresponsibilityApi.addResponsibility(AddResponsibilityRequest.builder()\n        .ownerId(user.id)\n        .resourceId(item.id)\n        .roleId(REQUESTER_ROLE_ID)\n        .resourceType(item.type)\n        .build())",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "checkAllAccessGranted": {
      "elementId": "checkAllAccessGranted",
      "elementName": "Check all access granted",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nint total = execution.getVariable('techStewards').size()\nint currentCount = execution.getVariable('grantedAccessCounter')\nexecution.setVariable('grantedAccessCounter', ++currentCount)\nif (currentCount == total) {\n    execution.setVariable('allAccessGranted', true)\n}",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "consolidateApprovers": {
      "elementId": "consolidateApprovers",
      "elementName": "Consolidate approvers",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\ndef approverUserExpression = execution.getVariable(\"approverUserExpression\")\ndef reportsApproverUserExpression = execution.getVariable(\"reportsApproverUserExpression\")\n\nSet userExpresionSet = []\n\nif(approverUserExpression != null) {\n    userExpresionSet.add(approverUserExpression)\n}\n\nif(reportsApproverUserExpression != null) {\n    userExpresionSet.add(reportsApproverUserExpression)\n}\n\nexecution.setVariable(\"approverUserExpression\", userExpresionSet.join(\",\"))",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "findReportApprovers": {
      "elementId": "findReportApprovers",
      "elementName": "Find approvers",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import com.collibra.dgc.core.api.dto.instance.responsibility.FindResponsibilitiesRequest\n                import com.collibra.dgc.core.api.model.ResourceType\n                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll\n                import com.collibra.dgc.core.api.model.instance.Asset\n                import com.collibra.dgc.core.api.dto.PagedResponse\n                import com.collibra.dgc.core.api.dto.user.FindUsersRequest\n\n                USER_LIMIT=1000\n                Set reports = execution.getVariable(\"reportsAssetList\")\n                Set approversList = []\n                OWNER_ROLE_ID ='00000000-0000-0000-0000-000000005040'\n                reports.each { reportId ->\n\n                 List<Asset> assets = new ArrayList<Asset>()\n                FindResponsibilitiesRequest.Builder builder = new FindResponsibilitiesRequest().builder()\n                Boolean moreToProcess = true\n                int offset = 0\n                while (moreToProcess) {\n                    builder\n                    .offset(offset)\n                    .limit(1000)\n                    PagedResponse<Asset> response = responsibilityApi.findResponsibilities(builder\n                            .roleIds([string2Uuid(OWNER_ROLE_ID)])\n                             .resourceIds([reportId])\n                            .build())\n                    assets.addAll(response.getResults())\n                    if (assets.size() == response.total) {\n                        moreToProcess = false\n                    } else {\n                        offset = assets.size()\n                    }\n                }\n                def responsibilities =assets;\n\n                def users = getUsersFromResponsibilities(responsibilities, USER_LIMIT)\n                //def users = responsibilities.collectMany {responsibilityApi.getUsers(it.id)}\n                approversList.add(users.collect { user -> \"user(\" + user.getUserName() + \")\"}.join(\",\"))\n                }\n\n                execution.setVariable(\"reportsApproverUserExpression\", approversList.join(\",\"))\n\n                def getUsersFromResponsibilities(responsibilities, limit) {\n                result = []\n                for (responsibility in responsibilities) {\n                result.addAll(getUsersFromResponsibility(responsibility, limit))\n                if (result.size() >= limit) {\n                return result.take(limit)\n                }\n                }\n\n                return result\n                }\n\n                def getUsersFromResponsibility(responsibility, limit) {\n                if (ResourceType.User == responsibility.owner.resourceType) {\n                return [userApi.getUser(responsibility.owner.id)]\n                } else if (ResourceType.UserGroup == responsibility.owner.resourceType) {\n                return userApi.findUsers(FindUsersRequest.builder()\n                .groupId(responsibility.owner.id)\n                .limit(limit)\n                .build()).getResults()\n                }\n                return []\n                }",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "generateDataUsageName": {
      "elementId": "generateDataUsageName",
      "elementName": "Generate data usage name",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import java.time.format.DateTimeFormatter\n                import java.time.LocalDate\n                import com.collibra.dgc.core.api.dto.instance.asset.FindAssetsRequest\n                import com.collibra.dgc.core.api.dto.MatchMode\n                import com.collibra.dgc.core.api.model.instance.Asset\n                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll\n\n                def getDateString() {\n                FORMATTER = DateTimeFormatter.ofPattern(\"yyyy-MM-dd\")\n                LocalDate date = LocalDate.now()\n                return date.format(FORMATTER)\n                }\n\n                private int getCounter(String prefix) {\n                // find all data usage requests for today\n                // Remark: we can't have 2 assets of the same name in a single domain\n                // must not check the type since another asset of another type might have a matching name (unlikely)\n\n                List result = paginateAll(assetApi::findAssets, () -> FindAssetsRequest.builder()\n                        .communityId(item.communityId)\n                        .domainId(item.domainId)\n                        .name(prefix)\n                        .nameMatchMode(MatchMode.START)\n                        .excludeMeta(false)\n                        .build());\n                // find the index of the latest data usage request for today\n                int maxIndex = 0;\n                for (Asset asset : result) {\n                String name = asset.getName()\n                int crossIndex = name.indexOf('#')\n                if (crossIndex > -1) {\n                int index = name.substring(crossIndex + 1) as Integer\n                maxIndex = Math.max(maxIndex, index)\n                }\n                }\n\n                return maxIndex + 1;\n                }\n\n\n                String dateString = getDateString()\n                String prefix = dateString + \" #\"\n                int counter = getCounter(prefix)\n                String result = prefix + counter\n                execution.setVariable(\"dataUsageName\", result)\n                loggerApi.debug(\"name set to ${result}\")",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "handleInvalidDataElement": {
      "elementId": "handleInvalidDataElement",
      "elementName": "Handle Invalid Data Element",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.workflow.api.exception.WorkflowException\n\nif (execution.getVariable(\"reasonForInvalidDataElements\") == 'workflowNoOwner') {\n    loggerApi.error(\"Cannot request data usage because at least one data element doesn't have an Owner role assigned to it.\");\n    throw new WorkflowException(translation.getMessage('workflowNoOwner'));\n}\nif (execution.getVariable(\"reasonForInvalidDataElements\") == 'workflowNoDataElementInShoppingBasket') {\n    loggerApi.error(\"Cannot request data usage when shopping basket is empty or only contains empty Data Sets.\");\n    throw new WorkflowException(translation.getMessage('workflowNoDataElementInShoppingBasket'));\n}",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "handleInvalidReports": {
      "elementId": "handleInvalidReports",
      "elementName": "HandleInvalidReports",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                throw new com.collibra.dgc.workflow.api.exception.WorkflowException(translation.getMessage('workflowNoOwner'))",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "identifyReportsAndDataSets": {
      "elementId": "identifyReportsAndDataSets",
      "elementName": "Identify reports and data sets",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest\n                import com.collibra.dgc.core.api.dto.meta.assettype.FindAssetTypesRequest\n                import com.collibra.dgc.core.api.dto.meta.assettype.FindSubAssetTypesRequest\n                import com.collibra.dgc.workflow.api.exception.WorkflowException\n                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll\n                def usageId = item.id\n                Set dataSets = []\n                Set reports = []\n                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'\n                REPORT_ASSET_TYPE_ID='00000000-0000-0000-0000-000000031102'\n                DATA_SET_ASSET_TYPE_ID='00000000-0000-0000-0001-000400000001'\n\n                def relations =  paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()\n                                               .targetId(usageId)\n                                               .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))\n                                               .build());\n\n                def findReportsChildrenAssetTypesRequest = FindSubAssetTypesRequest.builder()\n                .includeParent(true)\n                .assetTypeId(string2Uuid(REPORT_ASSET_TYPE_ID))\n                .build()\n                def findDataSetChildrenAssetTypesRequests = FindSubAssetTypesRequest.builder()\n                .includeParent(true)\n                .assetTypeId(string2Uuid(DATA_SET_ASSET_TYPE_ID))\n                .build()\n\n                def reportChildrenTypes = assetTypeApi.findSubTypes(findReportsChildrenAssetTypesRequest).collect { it.getId() }\n                def dataSetChildrenTypes = assetTypeApi.findSubTypes(findDataSetChildrenAssetTypesRequests).collect { it.getId() }\n\n                relations.each {\n                def source = it.getSource()\n                def sourceAssetTypeId = assetApi.getAsset(source.id).getType().getId()\n\n                if (sourceAssetTypeId in dataSetChildrenTypes) {\n                dataSets.add(source.getId())\n                } else if (sourceAssetTypeId in reportChildrenTypes) {\n                reports.add(source.getId());\n                } else {\n                throw new WorkflowException(translation.getMessage(\"dataBasketUnsupportedAssetType\", sourceAssetTypeId))\n                }\n                }\n\n                execution.setVariable(\"dataSetsAssetsList\", dataSets)\n                execution.setVariable(\"reportsAssetList\", reports)\n                execution.setVariable(\"containsDataSets\", dataSets.size() > 0)\n                execution.setVariable(\"containsReports\", reports.size() > 0)\n                execution.setVariable(\"dataSetsAccessGranted\", dataSets.size() == 0)",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "initDataUsageRequest": {
      "elementId": "initDataUsageRequest",
      "elementName": "Init data usage request",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.core.api.model.instance.Asset\nimport com.collibra.dgc.core.api.dto.instance.attribute.AddAttributeRequest\nimport com.collibra.dgc.core.api.dto.instance.asset.ChangeAssetRequest\nimport com.collibra.dgc.workflow.api.exception.WorkflowException\n\nPURPOSE_TYPE='00000000-0000-0000-0000-000000000207'\nSTATUS_INVALID='00000000-0000-0000-0000-000000005022'\nEFFECTIVE_START_DATE_TYPE='00000000-0000-0000-0000-000000000257'\nEFFECTIVE_END_DATE_TYPE='00000000-0000-0000-0000-000000000254'\n\nif (item == null) {\n    loggerApi.error(\"Cannot execute workflow. The context doesn't provide a valid Data Usage asset (no item)\")\n    throw new WorkflowException(translation.getMessage('workflowNoValidDataUsage'))\n}\nif (item.id == null) {\n    loggerApi.error(\"Cannot execute workflow. The context doesn't provide a valid Data Usage asset (item id is null)\")\n    throw new WorkflowException(translation.getMessage('workflowNoValidDataUsage'))\n}\n\nSTATUS_CANDIDATE = string2Uuid(\"00000000-0000-0000-0000-000000005008\")\n\nAsset usage = assetApi.getAsset(item.getId())\nvalidateStatus(usage)\nsetUsageReason(usage, execution)\nsetUsageStartTime(usage, execution)\nsetUsageEndTime(usage, execution)\n\nString dataUsageName = execution.getVariable('dataUsageName')\nassetApi.changeAsset(ChangeAssetRequest.builder()\n        .name(dataUsageName)\n        .displayName(dataUsageName)\n        .statusId(string2Uuid(STATUS_INVALID))\n        .id(item.id)\n        .build())\nexecution.setVariable(\"dataUsage\", usage)\n\ndef validateStatus(Asset usage) {\n    if (usage.status.id != STATUS_CANDIDATE) {\n        loggerApi.error(\"User tried to start a data usage request workflow on a data usage asset whose status is not 'Candidate'.\")\n        throw new WorkflowException(translation.getMessage('workflowDataUsageWrongStatus'))\n    }\n}\n\ndef setUsageStartTime(Asset asset, execution) {\n    def startDate = execution.getVariable('startTime')\n    attributeApi.addAttribute(AddAttributeRequest.builder()\n            .assetId(asset.getId())\n            .typeId(string2Uuid(EFFECTIVE_START_DATE_TYPE))\n            .value(startDate)\n            .build())\n}\n\ndef setUsageEndTime(Asset asset, execution) {\n    def endDate = execution.getVariable('endTime')\n    attributeApi.addAttribute(AddAttributeRequest.builder()\n            .assetId(asset.getId())\n            .typeId(string2Uuid(EFFECTIVE_END_DATE_TYPE))\n            .value(endDate)\n            .build())\n}\ndef setUsageReason(Asset asset, execution) {\n    String reason = execution.getVariable('usageRequestReason')\n    attributeApi.addAttribute(AddAttributeRequest.builder()\n            .assetId(asset.getId())\n            .typeId(string2Uuid(PURPOSE_TYPE))\n            .value(reason)\n            .build())\n}",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "markAsApprovalPending": {
      "elementId": "markAsApprovalPending",
      "elementName": "Mark as approval pending",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.core.api.dto.instance.asset.ChangeAssetRequest\n\nPENDING_STATUS_ID = string2Uuid(\"00000000-0000-0000-0000-000000005023\")\n\ndef changedAsset = assetApi.changeAsset(ChangeAssetRequest.builder()\n       .id(item.id)\n       .statusId(PENDING_STATUS_ID)\n       .build())",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "scripttask10": {
      "elementId": "scripttask10",
      "elementName": "Check if Purpose asset type exists",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.core.api.dto.meta.assettype.FindAssetTypesRequest\n\ndef prefix = \"Check if purpose asset type exist \"\nloggerApi.info(prefix + \"Started...\")\n\ndef isPurpose = internalIamLicenseApi.hasCapability(\"PRIVACY\") && assetTypeApi.exists(string2Uuid(\"c0e00000-0000-0000-0000-000000039021\")) && relationTypeApi.exists(string2Uuid(dataUsagePurposeRelationTypeUuid))\n\nloggerApi.info(prefix + \"boolean: \" + isPurpose)\nexecution.setVariable(\"isPurpose\", isPurpose)\nloggerApi.info(prefix + \"Ended!\")",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "scripttask11": {
      "elementId": "scripttask11",
      "elementName": "Add Purpose",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\ndef prefix = \"Adding purpose \"\nloggerApi.info(prefix + \"STARTED...\")\naddRelationToAsset(string2Uuid(dataUsagePurposeRelationTypeUuid), item.id, purpose)\n\ndef addRelationToAsset(relationTypeUuid,sourceUuid,targetUuid){\n    relationApi.addRelation(builders.get(\"AddRelationRequest\")\n            .typeId(relationTypeUuid)\n            .sourceId(sourceUuid)\n            .targetId(string2Uuid(targetUuid))\n            .build()\n    )\n}\n\nloggerApi.info(prefix + \"ENDED!\")",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "scripttask7": {
      "elementId": "scripttask7",
      "elementName": "Find Assets that need to have Data Analyst role assigned",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import com.collibra.dgc.core.api.model.instance.Asset\n                import com.collibra.dgc.core.api.dto.PagedResponse\n                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest\n                import com.collibra.catalog.api.component.businessmodel.dto.FindDataElementsRequest\n                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll\n\n                Set reportsAssetsIds = execution.getVariable(\"reportsAssetList\")\n\n                def usageId = item.id\n                Set assets = []\n                // item is a Data Usage asset, which holds relations to Data Sets\n                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'\n                def relations = paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()\n                                .targetId(usageId)\n                                .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))\n                                .build());\n                relations.each {\n                // the data set is the source of the relation\n                def term = it.getSource()\n                assets.add(term)\n                if(!(term.getId() in reportsAssetsIds)) {\n                assets.addAll(findDataElements(term.id))\n                }\n                }\n                def findDataElements(dataSetId) {\n                    List<Asset> assets = new ArrayList<Asset>()\n                    FindDataElementsRequest.Builder builder = new FindDataElementsRequest().builder()\n                    Boolean moreToProcess = true\n                    int offset = 0\n                    while (moreToProcess) {\n                        builder\n                                .offset(offset)\n                                .limit(1000)\n                        PagedResponse<Asset> response = dataSetApi.findDataElements(builder.dataSetId(dataSetId).build())\n                        assets.addAll(response.getResults())\n\n                        if (assets.size() == response.total) {\n                            moreToProcess = false\n                        } else {\n                            offset = assets.size()\n                        }\n                    }\n                    return assets\n                }\n                def assetIds = assets.collect{ uuid2String(it.id) }\n                execution.setVariable(\"dataAnalystLevel2Assets\", assetIds)",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "scripttask8": {
      "elementId": "scripttask8",
      "elementName": "Check if Data Analyst role is already assigned",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.core.api.dto.user.FindUsersRequest\nimport com.collibra.dgc.core.api.dto.instance.responsibility.FindResponsibilitiesRequest\nimport com.collibra.dgc.core.api.model.ResourceType\n\ndef requesterName = execution.getVariable(\"requester\")\ndef requester = userApi.findUsers(FindUsersRequest.builder()\n        .name(requesterName)\n        .build()).getResults().get(0).id\ndef dataElement = execution.getVariable(\"dataElement\")\n\nDATA_ANALYST_LEVEL_2_ROLE_ID = string2Uuid(\"00000000-0000-0000-0000-000000005062\")\n\ndef result\ntry {\n    def responsibilities = responsibilityApi.findResponsibilities(FindResponsibilitiesRequest.builder()\n            .roleIds([DATA_ANALYST_LEVEL_2_ROLE_ID])\n            .resourceIds([string2Uuid(dataElement)])\n            .ownerIds([requester])\n            .build()).results\n    def users = responsibilities.collect {getUserFromResponsibility(it)}.findAll()\n    result = users as boolean\n} catch (com.collibra.common.api.exception.ApiEntityNotFoundException e) {\n    result = false\n}\nexecution.setVariable(\"dataAnalystRoleAssigned\", result)\n\ndef getUserFromResponsibility(responsibility) {\n    if (ResourceType.User == responsibility.owner.resourceType) {\n        return userApi.getUser(responsibility.owner.id)\n    } else if (ResourceType.UserGroup == responsibility.owner.resourceType) {\n        return userApi.findUsers(FindUsersRequest.builder()\n                .groupId(responsibility.owner.id)\n                .limit(1)\n                .build()).getResults()\n                .find()\n\n    }\n    return null\n}\nresult",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "scripttask9": {
      "elementId": "scripttask9",
      "elementName": "Data Sets Access Granted",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nexecution.setVariable(\"dataSetsAccessGranted\", true)",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "servicetask1": {
      "elementId": "servicetask1",
      "elementName": "Init data usage request",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest\n                import com.collibra.dgc.core.api.model.instance.Asset\n                import com.collibra.dgc.core.api.model.instance.Relation\n                import com.collibra.dgc.core.api.model.user.User\n                import com.collibra.dgc.core.api.dto.PagedResponse\n                import com.collibra.dgc.workflow.api.exception.WorkflowException\n                import com.collibra.catalog.api.component.businessmodel.dto.FindDataElementsRequest\n                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll\n\n                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'\n                META_DATA_SET='00000000-0000-0000-0001-000400000001'\n                List relations = paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()\n                .targetId(item.id)\n                .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))\n                .build());\n\n\n                Set validators = new HashSet()\n                for (Relation relation : relations) {\n                // the data set is the source of the relation\n                Asset sourceDataSet = assetApi.getAsset(relation.source.id);\n                if (sourceDataSet != null && hasParentDataSetType(sourceDataSet)) {\n                validators.addAll(findValidatorsForDataset(sourceDataSet))\n                }\n                }\n\n                List asUserExpression = validators.collect {\"user(${it})\"}\n                execution.setVariable(\"approverUserExpression\", utility.toCsv(asUserExpression))\n\n                def findValidatorsForDataset(Asset sourceDataSet) {\n                def validators = []\n                for (Asset col : findDataElements(sourceDataSet.id)) {\n                User validator = columnApi.findValidatorForColumn(col.id)\n                if (validator == null) {\n                loggerApi.error(\"couldn't find a suitable approver for usage request on data set '\" +\n                sourceDataSet.getName() + \"' (no steward on asset and no creator id)\")\n                throw new WorkflowException(translation.getMessage('workflowNoApprover', sourceDataSet.getName()))\n                }\n                validators.add(validator.getUserName())\n                }\n\n                return validators\n                }\n\n                def hasParentDataSetType(Asset asset) {\n                string2Uuid(META_DATA_SET) == asset.type.id ||\n                assetTypeApi.findParentTypes(asset.type.id).any { string2Uuid(META_DATA_SET) == it.id }\n                }\n\n                def findDataElements(dataSetId) {\n                    List<Asset> assets = new ArrayList<Asset>()\n                    FindDataElementsRequest.Builder builder = new FindDataElementsRequest().builder()\n                    Boolean moreToProcess = true\n                    int offset = 0\n                    while (moreToProcess) {\n                        builder\n                                .offset(offset)\n                                .limit(1000)\n                        PagedResponse<Asset> response = dataSetApi.findDataElements(builder.dataSetId(dataSetId).build())\n                        assets.addAll(response.getResults())\n\n                        if (assets.size() == response.total) {\n                            moreToProcess = false\n                        } else {\n                            offset = assets.size()\n                        }\n                    }\n                    return assets\n                }",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "servicetask10": {
      "elementId": "servicetask10",
      "elementName": "Mark as refused",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import com.collibra.dgc.core.api.dto.instance.asset.ChangeAssetRequest\n\n                REJECTED_STATUS_ID = string2Uuid(\"00000000-0000-0000-0000-000000005010\")\n\n                def changedAsset = assetApi.changeAsset(ChangeAssetRequest.builder()\n                .id(item.id)\n                .statusId(REJECTED_STATUS_ID)\n                .build())",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "servicetask11": {
      "elementId": "servicetask11",
      "elementName": "Mark as access granted",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.core.api.dto.instance.asset.ChangeAssetRequest\n\nACCESS_GRANTED_STATUS_ID = string2Uuid(\"00000000-0000-0000-0000-000000005024\")\n\ndef changedAsset = assetApi.changeAsset(ChangeAssetRequest.builder()\n                .id(item.id)\n                .statusId(ACCESS_GRANTED_STATUS_ID)\n                .build())",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "servicetask15": {
      "elementId": "servicetask15",
      "elementName": "Assign Data Analyst Level 2 role on impacted data element",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.core.api.dto.instance.responsibility.AddResponsibilityRequest\nimport com.collibra.dgc.core.api.dto.user.FindUsersRequest\n\ndef user = userApi.findUsers(FindUsersRequest.builder()\n        .name(requester)\n        .build())\n        .getResults()\n        .first()\n\ndef asset = assetApi.getAsset(string2Uuid(dataElement))\n\nDATA_ANALYST_LEVEL_2_ROLE_ID = string2Uuid(\"00000000-0000-0000-0000-000000005062\")\n\nresponsibilityApi.addResponsibility(AddResponsibilityRequest.builder()\n        .ownerId(user.id)\n        .resourceId(asset.id)\n        .roleId(DATA_ANALYST_LEVEL_2_ROLE_ID)\n        .resourceType(asset.resourceType)\n        .build())",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "servicetask2": {
      "elementId": "servicetask2",
      "elementName": "Mark as accepted",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\nimport com.collibra.dgc.core.api.dto.instance.asset.ChangeAssetRequest\n\nACCEPTED_STATUS_ID = string2Uuid(\"00000000-0000-0000-0000-000000005009\")\n\ndef changedAsset = assetApi.changeAsset(ChangeAssetRequest.builder()\n                .id(item.id)\n                .statusId(ACCEPTED_STATUS_ID)\n                .build())",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "servicetask4": {
      "elementId": "servicetask4",
      "elementName": "notify requester",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\ndef usersIds = users.getUserIds(\"user(${requester})\")\nmail.sendMails(usersIds, \"usageAccepted\", null, execution)",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "servicetask8": {
      "elementId": "servicetask8",
      "elementName": "Identify technical stewards",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest\n                import com.collibra.dgc.core.api.model.instance.Asset\n                import com.collibra.dgc.core.api.dto.PagedResponse\n                import com.collibra.dgc.core.api.model.instance.Relation\n                import com.collibra.dgc.core.api.model.instance.Responsibility\n                import com.collibra.dgc.core.api.model.user.User\n                import com.collibra.dgc.core.api.dto.instance.responsibility.FindResponsibilitiesRequest\n                import com.collibra.dgc.core.api.model.ResourceType\n                import com.collibra.catalog.api.component.businessmodel.dto.FindDataElementsRequest\n                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll\n\n                USER_LIMIT = 1000\n                STEWARD_ROLE_ID='00000000-0000-0000-0000-000000005038'\n                OWNER_ROLE_ID ='00000000-0000-0000-0000-000000005040'\n                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'\n                META_DATA_SET='00000000-0000-0000-0001-000400000001'\n\n                def findTechStewardForDataSet(Asset sourceDataSet, Set validators) {\n                for (Asset col : findDataElements(sourceDataSet.id)) {\n                List validator = findTechnicalStewardsForColumn(col)\n                if (!validator.isEmpty()) {\n                for (User u : validator) {\n                validators.add(u.getUserName())\n                }\n                } else {\n                loggerApi.warn(\"couldn't find a suitable technical steward for usage request on data set '\" +\n                sourceDataSet.getName() + \"'\")\n                }\n                }\n                }\n\n                def findDataElements(dataSetId) {\n                List<Asset> assets = new ArrayList<Asset>()\n                FindDataElementsRequest.Builder builder = new FindDataElementsRequest().builder()\n                Boolean moreToProcess = true\n                int offset = 0\n                while (moreToProcess) {\n                    builder\n                            .offset(offset)\n                            .limit(1000)\n                    PagedResponse<Asset> response = dataSetApi.findDataElements(builder.dataSetId(dataSetId).build())\n                    assets.addAll(response.getResults())\n\n                    if (assets.size() == response.total) {\n                        moreToProcess = false\n                    } else {\n                        offset = assets.size()\n                    }\n                }\n                return assets\n                }\n\n                def findTechnicalStewardsForColumn(Asset column) {\n                List responsibilities = findResponsibilitiesForRoleOnResourceWithHierarchy(\n                string2Uuid(STEWARD_ROLE_ID),\n                column)\n                List validators = getUsersFromResponsibilities(responsibilities,USER_LIMIT)\n                if (validators.isEmpty()) {\n                responsibilities = findResponsibilitiesForRoleOnResourceWithHierarchy(\n                string2Uuid(OWNER_ROLE_ID),\n                column)\n                validators = getUsersFromResponsibilities(responsibilities,USER_LIMIT)\n                }\n                return validators\n                }\n                def getUsersFromResponsibilities(responsibilities, limit) {\n                result = []\n                for (responsibility in responsibilities) {\n                result.addAll(getUsersFromResponsibility(responsibility, limit))\n                if (result.size() >= limit) {\n                return result.take(limit)\n                }\n                }\n\n                return result\n                }\n\n                def getUsersFromResponsibility(responsibility, limit) {\n                if (ResourceType.User == responsibility.owner.resourceType) {\n                return [userApi.getUser(responsibility.owner.id)]\n                } else if (ResourceType.UserGroup == responsibility.owner.resourceType) {\n                return userApi.findUsers(FindUsersRequest.builder()\n                .groupId(responsibility.owner.id)\n                .limit(limit)\n                .build()).getResults()\n                }\n                return []\n                }\n\n  List findResponsibilitiesForRoleOnResourceWithHierarchy(UUID roleId, Asset asset) {\n                List<Asset> assets = new ArrayList<Asset>()\n                FindResponsibilitiesRequest.Builder builder = new FindResponsibilitiesRequest().builder()\n                Boolean moreToProcess = true\n                int offset = 0\n                while (moreToProcess) {\n                    builder\n                    .offset(offset)\n                    .limit(1000)\n                    PagedResponse<Asset> response = responsibilityApi.findResponsibilities(builder\n                         .resourceIds([asset.id])\n                        .includeInherited(true)\n                        .roleIds([roleId])\n                        .build())\n                    assets.addAll(response.getResults())\n                    if (assets.size() == response.total) {\n                        moreToProcess = false\n                    } else {\n                        offset = assets.size()\n                    }\n                }\n                return assets\n            }\n\n                 List relations = paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()\n                .targetId(item.id)\n                .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))\n                .build());\n\n                Set names = new HashSet()\n                relations.each { relation ->\n                Asset sourceAsset = assetApi.getAsset(relation.getSource().getId())\n                // find tech stewards only for data sets\n                if (hasParentDataSetType(sourceAsset)) {\n                findTechStewardForDataSet(sourceAsset, names)\n                }\n                }\n                execution.setVariable('techStewards', names)\n                execution.setVariable('allAccessGranted', false)\n                execution.setVariable('grantedAccessCounter', 0)\n\n\n                def hasParentDataSetType(Asset asset) {\n                string2Uuid(META_DATA_SET) == asset.type.id ||\n                assetTypeApi.findParentTypes(asset.type.id).any { string2Uuid(META_DATA_SET) == it.id }\n                }",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "servicetask9": {
      "elementId": "servicetask9",
      "elementName": "notify rejected approval",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n        def usersIds = users.getUserIds(\"user(${requester})\")\n        mail.sendMails(usersIds, \"usageRefused\", null, execution)",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "validateDataElements": {
      "elementId": "validateDataElements",
      "elementName": "Validate data elements",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest\n                import com.collibra.dgc.core.api.model.instance.Asset\n                import com.collibra.dgc.core.api.dto.PagedResponse\n                import com.collibra.dgc.core.api.model.instance.Relation\n                import com.collibra.dgc.core.api.model.user.User\n                import com.collibra.catalog.api.component.businessmodel.dto.FindDataElementsRequest\n                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll\n\n                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'\n                META_DATA_SET='00000000-0000-0000-0001-000400000001'\n\n                boolean valid = false\n                Asset usage = assetApi.getAsset(item.id)\n                List columns = getColumns(usage)\n                if (columns.size() == 0) {\n                execution.setVariable('reasonForInvalidDataElements', 'workflowNoDataElementInShoppingBasket')\n                } else {\n                valid = checkDataElements(columns)\n                if (!valid) {\n                execution.setVariable('reasonForInvalidDataElements', 'workflowNoOwner')\n                }\n                }\n\n                execution.setVariable(\"validDataElements\", valid)\n\n                def getColumns(Asset usage) {\n                def columns = []\n                // usage is a Data Usage asset, which holds relations to Data Sets\n                List relations =paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()\n                .targetId(usage.id)\n                .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))\n                .build());\n\n                for (Relation relation : relations) {\n                // the data set is the source of the relation\n                Asset sourceDataSet = assetApi.getAsset(relation.source.id)\n                if (hasParentDataSetType(sourceDataSet)) {\n                columns.addAll(findDataElements(sourceDataSet.id))\n                }\n                }\n\n\n                return columns\n                }\n                def findDataElements(dataSetId) {\n                    List<Asset> assets = new ArrayList<Asset>()\n                    FindDataElementsRequest.Builder builder = new FindDataElementsRequest().builder()\n                    Boolean moreToProcess = true\n                    int offset = 0\n                    while (moreToProcess) {\n                        builder\n                                .offset(offset)\n                                .limit(1000)\n                        PagedResponse<Asset> response = dataSetApi.findDataElements(builder.dataSetId(dataSetId).build())\n                        assets.addAll(response.getResults())\n\n                        if (assets.size() == response.total) {\n                            moreToProcess = false\n                        } else {\n                            offset = assets.size()\n                        }\n                    }\n                    return assets\n                }\n\n                def hasParentDataSetType(Asset asset) {\n                string2Uuid(META_DATA_SET) == asset.type.id ||\n                assetTypeApi.findParentTypes(asset.type.id).any { string2Uuid(META_DATA_SET) == it.id }\n                }\n\n                private boolean checkDataElements(List columns) {\n                for (Asset col : columns) {\n                User user = columnApi.findValidatorForColumn(col.id)\n                if (user == null) {\n                loggerApi.error(\"The following column is part of the request and has no owner: \" + col\n                .getName() + \" (\" + col.getId() + \")\");\n                return false\n                }\n                }\n                return true\n                }",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    },
    "validateReports": {
      "elementId": "validateReports",
      "elementName": "Validate reports",
      "elementType": "bpmn:ScriptTask",
      "groovy": "// #importFile NONE\n                import com.collibra.dgc.core.api.dto.instance.responsibility.FindResponsibilitiesRequest\n                import com.collibra.dgc.core.api.model.ResourceType\n                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll\n                import com.collibra.dgc.core.api.model.instance.Asset\n                import com.collibra.dgc.core.api.dto.PagedResponse\n                import com.collibra.dgc.core.api.dto.user.FindUsersRequest\n\n                Set reports = execution.getVariable(\"reportsAssetList\")\n\n                def reportOwnersChecks = []\n                OWNER_ROLE_ID ='00000000-0000-0000-0000-000000005040'\n                reports.each {\n                        List assets = new ArrayList()\n                        FindResponsibilitiesRequest.Builder builder = new FindResponsibilitiesRequest().builder()\n                        Boolean moreToProcess = true\n                        int offset = 0\n                        while (moreToProcess) {\n                             builder\n                            .offset(offset)\n                            .limit(1000)\n                            PagedResponse<Asset> response = responsibilityApi.findResponsibilities(builder\n                                    .roleIds([string2Uuid(OWNER_ROLE_ID)])\n                                    .resourceIds([it])\n                                    .build())\n                            assets.addAll(response.getResults())\n                            if (assets.size() == response.total) {\n                                moreToProcess = false\n                            } else {\n                                offset = assets.size()\n                            }\n                        }\n                def responsibilities = assets;\n                def owners = responsibilities.collect {getUserFromResponsibility(it)}.findAll()\n                reportOwnersChecks << owners.asBoolean()\n                }\n\n                execution.setVariable(\"validReports\", reportOwnersChecks.every { it == true })\n\n                def getUserFromResponsibility(responsibility) {\n                if (ResourceType.User == responsibility.owner.resourceType) {\n                return userApi.getUser(responsibility.owner.id)\n                } else if (ResourceType.UserGroup == responsibility.owner.resourceType) {\n                return userApi.findUsers(FindUsersRequest.builder()\n                .groupId(responsibility.owner.id)\n                .limit(1)\n                .build()).getResults()\n                .find()\n\n                }\n                return null\n                }",
      "importedFrom": "bpmn:scriptTask",
      "scriptFormat": "groovy",
      "source": "RequestDataSetsAccess.bpmn"
    }
  },
  "theme": "theme-1",
  "url": null,
  "usersAccess": null,
  "uuidMappings": {},
  "validationRules": []
}