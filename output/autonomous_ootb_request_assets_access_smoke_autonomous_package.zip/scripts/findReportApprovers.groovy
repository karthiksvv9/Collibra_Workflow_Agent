// #importFile NONE
                import com.collibra.dgc.core.api.dto.instance.responsibility.FindResponsibilitiesRequest
                import com.collibra.dgc.core.api.model.ResourceType
                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll
                import com.collibra.dgc.core.api.model.instance.Asset
                import com.collibra.dgc.core.api.dto.PagedResponse
                import com.collibra.dgc.core.api.dto.user.FindUsersRequest

                USER_LIMIT=1000
                Set reports = execution.getVariable("reportsAssetList")
                Set approversList = []
                OWNER_ROLE_ID ='00000000-0000-0000-0000-000000005040'
                reports.each { reportId ->

                 List<Asset> assets = new ArrayList<Asset>()
                FindResponsibilitiesRequest.Builder builder = new FindResponsibilitiesRequest().builder()
                Boolean moreToProcess = true
                int offset = 0
                while (moreToProcess) {
                    builder
                    .offset(offset)
                    .limit(1000)
                    PagedResponse<Asset> response = responsibilityApi.findResponsibilities(builder
                            .roleIds([string2Uuid(OWNER_ROLE_ID)])
                             .resourceIds([reportId])
                            .build())
                    assets.addAll(response.getResults())
                    if (assets.size() == response.total) {
                        moreToProcess = false
                    } else {
                        offset = assets.size()
                    }
                }
                def responsibilities =assets;

                def users = getUsersFromResponsibilities(responsibilities, USER_LIMIT)
                //def users = responsibilities.collectMany {responsibilityApi.getUsers(it.id)}
                approversList.add(users.collect { user -> "user(" + user.getUserName() + ")"}.join(","))
                }

                execution.setVariable("reportsApproverUserExpression", approversList.join(","))

                def getUsersFromResponsibilities(responsibilities, limit) {
                result = []
                for (responsibility in responsibilities) {
                result.addAll(getUsersFromResponsibility(responsibility, limit))
                if (result.size() >= limit) {
                return result.take(limit)
                }
                }

                return result
                }

                def getUsersFromResponsibility(responsibility, limit) {
                if (ResourceType.User == responsibility.owner.resourceType) {
                return [userApi.getUser(responsibility.owner.id)]
                } else if (ResourceType.UserGroup == responsibility.owner.resourceType) {
                return userApi.findUsers(FindUsersRequest.builder()
                .groupId(responsibility.owner.id)
                .limit(limit)
                .build()).getResults()
                }
                return []
                }