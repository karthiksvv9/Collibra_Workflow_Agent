// #importFile NONE
int total = execution.getVariable('techStewards').size()
int currentCount = execution.getVariable('grantedAccessCounter')
execution.setVariable('grantedAccessCounter', ++currentCount)
if (currentCount == total) {
    execution.setVariable('allAccessGranted', true)
}