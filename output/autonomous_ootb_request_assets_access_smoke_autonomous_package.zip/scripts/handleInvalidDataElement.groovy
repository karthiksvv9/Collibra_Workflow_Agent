// #importFile NONE
import com.collibra.dgc.workflow.api.exception.WorkflowException

if (execution.getVariable("reasonForInvalidDataElements") == 'workflowNoOwner') {
    loggerApi.error("Cannot request data usage because at least one data element doesn't have an Owner role assigned to it.");
    throw new WorkflowException(translation.getMessage('workflowNoOwner'));
}
if (execution.getVariable("reasonForInvalidDataElements") == 'workflowNoDataElementInShoppingBasket') {
    loggerApi.error("Cannot request data usage when shopping basket is empty or only contains empty Data Sets.");
    throw new WorkflowException(translation.getMessage('workflowNoDataElementInShoppingBasket'));
}