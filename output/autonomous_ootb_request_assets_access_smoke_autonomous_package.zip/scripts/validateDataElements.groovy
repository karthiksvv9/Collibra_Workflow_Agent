// #importFile NONE
                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest
                import com.collibra.dgc.core.api.model.instance.Asset
                import com.collibra.dgc.core.api.dto.PagedResponse
                import com.collibra.dgc.core.api.model.instance.Relation
                import com.collibra.dgc.core.api.model.user.User
                import com.collibra.catalog.api.component.businessmodel.dto.FindDataElementsRequest
                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll

                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'
                META_DATA_SET='00000000-0000-0000-0001-000400000001'

                boolean valid = false
                Asset usage = assetApi.getAsset(item.id)
                List columns = getColumns(usage)
                if (columns.size() == 0) {
                execution.setVariable('reasonForInvalidDataElements', 'workflowNoDataElementInShoppingBasket')
                } else {
                valid = checkDataElements(columns)
                if (!valid) {
                execution.setVariable('reasonForInvalidDataElements', 'workflowNoOwner')
                }
                }

                execution.setVariable("validDataElements", valid)

                def getColumns(Asset usage) {
                def columns = []
                // usage is a Data Usage asset, which holds relations to Data Sets
                List relations =paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()
                .targetId(usage.id)
                .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))
                .build());

                for (Relation relation : relations) {
                // the data set is the source of the relation
                Asset sourceDataSet = assetApi.getAsset(relation.source.id)
                if (hasParentDataSetType(sourceDataSet)) {
                columns.addAll(findDataElements(sourceDataSet.id))
                }
                }


                return columns
                }
                def findDataElements(dataSetId) {
                    List<Asset> assets = new ArrayList<Asset>()
                    FindDataElementsRequest.Builder builder = new FindDataElementsRequest().builder()
                    Boolean moreToProcess = true
                    int offset = 0
                    while (moreToProcess) {
                        builder
                                .offset(offset)
                                .limit(1000)
                        PagedResponse<Asset> response = dataSetApi.findDataElements(builder.dataSetId(dataSetId).build())
                        assets.addAll(response.getResults())

                        if (assets.size() == response.total) {
                            moreToProcess = false
                        } else {
                            offset = assets.size()
                        }
                    }
                    return assets
                }

                def hasParentDataSetType(Asset asset) {
                string2Uuid(META_DATA_SET) == asset.type.id ||
                assetTypeApi.findParentTypes(asset.type.id).any { string2Uuid(META_DATA_SET) == it.id }
                }

                private boolean checkDataElements(List columns) {
                for (Asset col : columns) {
                User user = columnApi.findValidatorForColumn(col.id)
                if (user == null) {
                loggerApi.error("The following column is part of the request and has no owner: " + col
                .getName() + " (" + col.getId() + ")");
                return false
                }
                }
                return true
                }