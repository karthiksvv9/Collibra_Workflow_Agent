// #importFile NONE
                throw new com.collibra.dgc.workflow.api.exception.WorkflowException(translation.getMessage('workflowNoOwner'))