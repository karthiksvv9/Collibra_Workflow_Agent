// #importFile NONE
def prefix = "Adding purpose "
loggerApi.info(prefix + "STARTED...")
addRelationToAsset(string2Uuid(dataUsagePurposeRelationTypeUuid), item.id, purpose)

def addRelationToAsset(relationTypeUuid,sourceUuid,targetUuid){
    relationApi.addRelation(builders.get("AddRelationRequest")
            .typeId(relationTypeUuid)
            .sourceId(sourceUuid)
            .targetId(string2Uuid(targetUuid))
            .build()
    )
}

loggerApi.info(prefix + "ENDED!")