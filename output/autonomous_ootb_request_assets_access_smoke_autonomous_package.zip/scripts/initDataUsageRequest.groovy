// #importFile NONE
import com.collibra.dgc.core.api.model.instance.Asset
import com.collibra.dgc.core.api.dto.instance.attribute.AddAttributeRequest
import com.collibra.dgc.core.api.dto.instance.asset.ChangeAssetRequest
import com.collibra.dgc.workflow.api.exception.WorkflowException

PURPOSE_TYPE='00000000-0000-0000-0000-000000000207'
STATUS_INVALID='00000000-0000-0000-0000-000000005022'
EFFECTIVE_START_DATE_TYPE='00000000-0000-0000-0000-000000000257'
EFFECTIVE_END_DATE_TYPE='00000000-0000-0000-0000-000000000254'

if (item == null) {
    loggerApi.error("Cannot execute workflow. The context doesn't provide a valid Data Usage asset (no item)")
    throw new WorkflowException(translation.getMessage('workflowNoValidDataUsage'))
}
if (item.id == null) {
    loggerApi.error("Cannot execute workflow. The context doesn't provide a valid Data Usage asset (item id is null)")
    throw new WorkflowException(translation.getMessage('workflowNoValidDataUsage'))
}

STATUS_CANDIDATE = string2Uuid("00000000-0000-0000-0000-000000005008")

Asset usage = assetApi.getAsset(item.getId())
validateStatus(usage)
setUsageReason(usage, execution)
setUsageStartTime(usage, execution)
setUsageEndTime(usage, execution)

String dataUsageName = execution.getVariable('dataUsageName')
assetApi.changeAsset(ChangeAssetRequest.builder()
        .name(dataUsageName)
        .displayName(dataUsageName)
        .statusId(string2Uuid(STATUS_INVALID))
        .id(item.id)
        .build())
execution.setVariable("dataUsage", usage)

def validateStatus(Asset usage) {
    if (usage.status.id != STATUS_CANDIDATE) {
        loggerApi.error("User tried to start a data usage request workflow on a data usage asset whose status is not 'Candidate'.")
        throw new WorkflowException(translation.getMessage('workflowDataUsageWrongStatus'))
    }
}

def setUsageStartTime(Asset asset, execution) {
    def startDate = execution.getVariable('startTime')
    attributeApi.addAttribute(AddAttributeRequest.builder()
            .assetId(asset.getId())
            .typeId(string2Uuid(EFFECTIVE_START_DATE_TYPE))
            .value(startDate)
            .build())
}

def setUsageEndTime(Asset asset, execution) {
    def endDate = execution.getVariable('endTime')
    attributeApi.addAttribute(AddAttributeRequest.builder()
            .assetId(asset.getId())
            .typeId(string2Uuid(EFFECTIVE_END_DATE_TYPE))
            .value(endDate)
            .build())
}
def setUsageReason(Asset asset, execution) {
    String reason = execution.getVariable('usageRequestReason')
    attributeApi.addAttribute(AddAttributeRequest.builder()
            .assetId(asset.getId())
            .typeId(string2Uuid(PURPOSE_TYPE))
            .value(reason)
            .build())
}