// #importFile NONE
import com.collibra.dgc.core.api.dto.meta.assettype.FindAssetTypesRequest

def prefix = "Check if purpose asset type exist "
loggerApi.info(prefix + "Started...")

def isPurpose = internalIamLicenseApi.hasCapability("PRIVACY") && assetTypeApi.exists(string2Uuid("c0e00000-0000-0000-0000-000000039021")) && relationTypeApi.exists(string2Uuid(dataUsagePurposeRelationTypeUuid))

loggerApi.info(prefix + "boolean: " + isPurpose)
execution.setVariable("isPurpose", isPurpose)
loggerApi.info(prefix + "Ended!")