// #importFile NONE
execution.setVariable("dataSetsAccessGranted", true)