// #importFile NONE
                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest
                import com.collibra.dgc.core.api.dto.meta.assettype.FindAssetTypesRequest
                import com.collibra.dgc.core.api.dto.meta.assettype.FindSubAssetTypesRequest
                import com.collibra.dgc.workflow.api.exception.WorkflowException
                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll
                def usageId = item.id
                Set dataSets = []
                Set reports = []
                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'
                REPORT_ASSET_TYPE_ID='00000000-0000-0000-0000-000000031102'
                DATA_SET_ASSET_TYPE_ID='00000000-0000-0000-0001-000400000001'

                def relations =  paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()
                                               .targetId(usageId)
                                               .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))
                                               .build());

                def findReportsChildrenAssetTypesRequest = FindSubAssetTypesRequest.builder()
                .includeParent(true)
                .assetTypeId(string2Uuid(REPORT_ASSET_TYPE_ID))
                .build()
                def findDataSetChildrenAssetTypesRequests = FindSubAssetTypesRequest.builder()
                .includeParent(true)
                .assetTypeId(string2Uuid(DATA_SET_ASSET_TYPE_ID))
                .build()

                def reportChildrenTypes = assetTypeApi.findSubTypes(findReportsChildrenAssetTypesRequest).collect { it.getId() }
                def dataSetChildrenTypes = assetTypeApi.findSubTypes(findDataSetChildrenAssetTypesRequests).collect { it.getId() }

                relations.each {
                def source = it.getSource()
                def sourceAssetTypeId = assetApi.getAsset(source.id).getType().getId()

                if (sourceAssetTypeId in dataSetChildrenTypes) {
                dataSets.add(source.getId())
                } else if (sourceAssetTypeId in reportChildrenTypes) {
                reports.add(source.getId());
                } else {
                throw new WorkflowException(translation.getMessage("dataBasketUnsupportedAssetType", sourceAssetTypeId))
                }
                }

                execution.setVariable("dataSetsAssetsList", dataSets)
                execution.setVariable("reportsAssetList", reports)
                execution.setVariable("containsDataSets", dataSets.size() > 0)
                execution.setVariable("containsReports", reports.size() > 0)
                execution.setVariable("dataSetsAccessGranted", dataSets.size() == 0)