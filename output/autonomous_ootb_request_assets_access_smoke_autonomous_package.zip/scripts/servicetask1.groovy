// #importFile NONE
                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest
                import com.collibra.dgc.core.api.model.instance.Asset
                import com.collibra.dgc.core.api.model.instance.Relation
                import com.collibra.dgc.core.api.model.user.User
                import com.collibra.dgc.core.api.dto.PagedResponse
                import com.collibra.dgc.workflow.api.exception.WorkflowException
                import com.collibra.catalog.api.component.businessmodel.dto.FindDataElementsRequest
                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll

                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'
                META_DATA_SET='00000000-0000-0000-0001-000400000001'
                List relations = paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()
                .targetId(item.id)
                .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))
                .build());


                Set validators = new HashSet()
                for (Relation relation : relations) {
                // the data set is the source of the relation
                Asset sourceDataSet = assetApi.getAsset(relation.source.id);
                if (sourceDataSet != null && hasParentDataSetType(sourceDataSet)) {
                validators.addAll(findValidatorsForDataset(sourceDataSet))
                }
                }

                List asUserExpression = validators.collect {"user(${it})"}
                execution.setVariable("approverUserExpression", utility.toCsv(asUserExpression))

                def findValidatorsForDataset(Asset sourceDataSet) {
                def validators = []
                for (Asset col : findDataElements(sourceDataSet.id)) {
                User validator = columnApi.findValidatorForColumn(col.id)
                if (validator == null) {
                loggerApi.error("couldn't find a suitable approver for usage request on data set '" +
                sourceDataSet.getName() + "' (no steward on asset and no creator id)")
                throw new WorkflowException(translation.getMessage('workflowNoApprover', sourceDataSet.getName()))
                }
                validators.add(validator.getUserName())
                }

                return validators
                }

                def hasParentDataSetType(Asset asset) {
                string2Uuid(META_DATA_SET) == asset.type.id ||
                assetTypeApi.findParentTypes(asset.type.id).any { string2Uuid(META_DATA_SET) == it.id }
                }

                def findDataElements(dataSetId) {
                    List<Asset> assets = new ArrayList<Asset>()
                    FindDataElementsRequest.Builder builder = new FindDataElementsRequest().builder()
                    Boolean moreToProcess = true
                    int offset = 0
                    while (moreToProcess) {
                        builder
                                .offset(offset)
                                .limit(1000)
                        PagedResponse<Asset> response = dataSetApi.findDataElements(builder.dataSetId(dataSetId).build())
                        assets.addAll(response.getResults())

                        if (assets.size() == response.total) {
                            moreToProcess = false
                        } else {
                            offset = assets.size()
                        }
                    }
                    return assets
                }