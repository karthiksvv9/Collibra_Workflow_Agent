// #importFile NONE
                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest
                import com.collibra.dgc.core.api.model.instance.Asset
                import com.collibra.dgc.core.api.dto.PagedResponse
                import com.collibra.dgc.core.api.model.instance.Relation
                import com.collibra.dgc.core.api.model.instance.Responsibility
                import com.collibra.dgc.core.api.model.user.User
                import com.collibra.dgc.core.api.dto.instance.responsibility.FindResponsibilitiesRequest
                import com.collibra.dgc.core.api.model.ResourceType
                import com.collibra.catalog.api.component.businessmodel.dto.FindDataElementsRequest
                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll

                USER_LIMIT = 1000
                STEWARD_ROLE_ID='00000000-0000-0000-0000-000000005038'
                OWNER_ROLE_ID ='00000000-0000-0000-0000-000000005040'
                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'
                META_DATA_SET='00000000-0000-0000-0001-000400000001'

                def findTechStewardForDataSet(Asset sourceDataSet, Set validators) {
                for (Asset col : findDataElements(sourceDataSet.id)) {
                List validator = findTechnicalStewardsForColumn(col)
                if (!validator.isEmpty()) {
                for (User u : validator) {
                validators.add(u.getUserName())
                }
                } else {
                loggerApi.warn("couldn't find a suitable technical steward for usage request on data set '" +
                sourceDataSet.getName() + "'")
                }
                }
                }

                def findDataElements(dataSetId) {
                List<Asset> assets = new ArrayList<Asset>()
                FindDataElementsRequest.Builder builder = new FindDataElementsRequest().builder()
                Boolean moreToProcess = true
                int offset = 0
                while (moreToProcess) {
                    builder
                            .offset(offset)
                            .limit(1000)
                    PagedResponse<Asset> response = dataSetApi.findDataElements(builder.dataSetId(dataSetId).build())
                    assets.addAll(response.getResults())

                    if (assets.size() == response.total) {
                        moreToProcess = false
                    } else {
                        offset = assets.size()
                    }
                }
                return assets
                }

                def findTechnicalStewardsForColumn(Asset column) {
                List responsibilities = findResponsibilitiesForRoleOnResourceWithHierarchy(
                string2Uuid(STEWARD_ROLE_ID),
                column)
                List validators = getUsersFromResponsibilities(responsibilities,USER_LIMIT)
                if (validators.isEmpty()) {
                responsibilities = findResponsibilitiesForRoleOnResourceWithHierarchy(
                string2Uuid(OWNER_ROLE_ID),
                column)
                validators = getUsersFromResponsibilities(responsibilities,USER_LIMIT)
                }
                return validators
                }
                def getUsersFromResponsibilities(responsibilities, limit) {
                result = []
                for (responsibility in responsibilities) {
                result.addAll(getUsersFromResponsibility(responsibility, limit))
                if (result.size() >= limit) {
                return result.take(limit)
                }
                }

                return result
                }

                def getUsersFromResponsibility(responsibility, limit) {
                if (ResourceType.User == responsibility.owner.resourceType) {
                return [userApi.getUser(responsibility.owner.id)]
                } else if (ResourceType.UserGroup == responsibility.owner.resourceType) {
                return userApi.findUsers(FindUsersRequest.builder()
                .groupId(responsibility.owner.id)
                .limit(limit)
                .build()).getResults()
                }
                return []
                }

  List findResponsibilitiesForRoleOnResourceWithHierarchy(UUID roleId, Asset asset) {
                List<Asset> assets = new ArrayList<Asset>()
                FindResponsibilitiesRequest.Builder builder = new FindResponsibilitiesRequest().builder()
                Boolean moreToProcess = true
                int offset = 0
                while (moreToProcess) {
                    builder
                    .offset(offset)
                    .limit(1000)
                    PagedResponse<Asset> response = responsibilityApi.findResponsibilities(builder
                         .resourceIds([asset.id])
                        .includeInherited(true)
                        .roleIds([roleId])
                        .build())
                    assets.addAll(response.getResults())
                    if (assets.size() == response.total) {
                        moreToProcess = false
                    } else {
                        offset = assets.size()
                    }
                }
                return assets
            }

                 List relations = paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()
                .targetId(item.id)
                .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))
                .build());

                Set names = new HashSet()
                relations.each { relation ->
                Asset sourceAsset = assetApi.getAsset(relation.getSource().getId())
                // find tech stewards only for data sets
                if (hasParentDataSetType(sourceAsset)) {
                findTechStewardForDataSet(sourceAsset, names)
                }
                }
                execution.setVariable('techStewards', names)
                execution.setVariable('allAccessGranted', false)
                execution.setVariable('grantedAccessCounter', 0)


                def hasParentDataSetType(Asset asset) {
                string2Uuid(META_DATA_SET) == asset.type.id ||
                assetTypeApi.findParentTypes(asset.type.id).any { string2Uuid(META_DATA_SET) == it.id }
                }