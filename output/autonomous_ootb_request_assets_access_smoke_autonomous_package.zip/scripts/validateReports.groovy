// #importFile NONE
                import com.collibra.dgc.core.api.dto.instance.responsibility.FindResponsibilitiesRequest
                import com.collibra.dgc.core.api.model.ResourceType
                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll
                import com.collibra.dgc.core.api.model.instance.Asset
                import com.collibra.dgc.core.api.dto.PagedResponse
                import com.collibra.dgc.core.api.dto.user.FindUsersRequest

                Set reports = execution.getVariable("reportsAssetList")

                def reportOwnersChecks = []
                OWNER_ROLE_ID ='00000000-0000-0000-0000-000000005040'
                reports.each {
                        List assets = new ArrayList()
                        FindResponsibilitiesRequest.Builder builder = new FindResponsibilitiesRequest().builder()
                        Boolean moreToProcess = true
                        int offset = 0
                        while (moreToProcess) {
                             builder
                            .offset(offset)
                            .limit(1000)
                            PagedResponse<Asset> response = responsibilityApi.findResponsibilities(builder
                                    .roleIds([string2Uuid(OWNER_ROLE_ID)])
                                    .resourceIds([it])
                                    .build())
                            assets.addAll(response.getResults())
                            if (assets.size() == response.total) {
                                moreToProcess = false
                            } else {
                                offset = assets.size()
                            }
                        }
                def responsibilities = assets;
                def owners = responsibilities.collect {getUserFromResponsibility(it)}.findAll()
                reportOwnersChecks << owners.asBoolean()
                }

                execution.setVariable("validReports", reportOwnersChecks.every { it == true })

                def getUserFromResponsibility(responsibility) {
                if (ResourceType.User == responsibility.owner.resourceType) {
                return userApi.getUser(responsibility.owner.id)
                } else if (ResourceType.UserGroup == responsibility.owner.resourceType) {
                return userApi.findUsers(FindUsersRequest.builder()
                .groupId(responsibility.owner.id)
                .limit(1)
                .build()).getResults()
                .find()

                }
                return null
                }