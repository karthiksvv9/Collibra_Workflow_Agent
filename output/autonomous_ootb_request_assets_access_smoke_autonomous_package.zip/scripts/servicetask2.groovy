// #importFile NONE
import com.collibra.dgc.core.api.dto.instance.asset.ChangeAssetRequest

ACCEPTED_STATUS_ID = string2Uuid("00000000-0000-0000-0000-000000005009")

def changedAsset = assetApi.changeAsset(ChangeAssetRequest.builder()
                .id(item.id)
                .statusId(ACCEPTED_STATUS_ID)
                .build())