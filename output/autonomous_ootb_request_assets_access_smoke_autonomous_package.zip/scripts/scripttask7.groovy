// #importFile NONE
                import com.collibra.dgc.core.api.model.instance.Asset
                import com.collibra.dgc.core.api.dto.PagedResponse
                import com.collibra.dgc.core.api.dto.instance.relation.FindRelationsRequest
                import com.collibra.catalog.api.component.businessmodel.dto.FindDataElementsRequest
                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll

                Set reportsAssetsIds = execution.getVariable("reportsAssetList")

                def usageId = item.id
                Set assets = []
                // item is a Data Usage asset, which holds relations to Data Sets
                ASSET_IS_ESSENTIAL_FOR_DATA_USAGE='00000000-0000-0000-0000-000000007061'
                def relations = paginateAll(relationApi::findRelations, () -> FindRelationsRequest.builder()
                                .targetId(usageId)
                                .relationTypeId(string2Uuid(ASSET_IS_ESSENTIAL_FOR_DATA_USAGE))
                                .build());
                relations.each {
                // the data set is the source of the relation
                def term = it.getSource()
                assets.add(term)
                if(!(term.getId() in reportsAssetsIds)) {
                assets.addAll(findDataElements(term.id))
                }
                }
                def findDataElements(dataSetId) {
                    List<Asset> assets = new ArrayList<Asset>()
                    FindDataElementsRequest.Builder builder = new FindDataElementsRequest().builder()
                    Boolean moreToProcess = true
                    int offset = 0
                    while (moreToProcess) {
                        builder
                                .offset(offset)
                                .limit(1000)
                        PagedResponse<Asset> response = dataSetApi.findDataElements(builder.dataSetId(dataSetId).build())
                        assets.addAll(response.getResults())

                        if (assets.size() == response.total) {
                            moreToProcess = false
                        } else {
                            offset = assets.size()
                        }
                    }
                    return assets
                }
                def assetIds = assets.collect{ uuid2String(it.id) }
                execution.setVariable("dataAnalystLevel2Assets", assetIds)