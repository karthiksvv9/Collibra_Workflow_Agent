// #importFile NONE
                import java.time.format.DateTimeFormatter
                import java.time.LocalDate
                import com.collibra.dgc.core.api.dto.instance.asset.FindAssetsRequest
                import com.collibra.dgc.core.api.dto.MatchMode
                import com.collibra.dgc.core.api.model.instance.Asset
                import static com.collibra.catalog.core.businessmodel.paging.PagingHelper.paginateAll

                def getDateString() {
                FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd")
                LocalDate date = LocalDate.now()
                return date.format(FORMATTER)
                }

                private int getCounter(String prefix) {
                // find all data usage requests for today
                // Remark: we can't have 2 assets of the same name in a single domain
                // must not check the type since another asset of another type might have a matching name (unlikely)

                List result = paginateAll(assetApi::findAssets, () -> FindAssetsRequest.builder()
                        .communityId(item.communityId)
                        .domainId(item.domainId)
                        .name(prefix)
                        .nameMatchMode(MatchMode.START)
                        .excludeMeta(false)
                        .build());
                // find the index of the latest data usage request for today
                int maxIndex = 0;
                for (Asset asset : result) {
                String name = asset.getName()
                int crossIndex = name.indexOf('#')
                if (crossIndex > -1) {
                int index = name.substring(crossIndex + 1) as Integer
                maxIndex = Math.max(maxIndex, index)
                }
                }

                return maxIndex + 1;
                }


                String dateString = getDateString()
                String prefix = dateString + " #"
                int counter = getCounter(prefix)
                String result = prefix + counter
                execution.setVariable("dataUsageName", result)
                loggerApi.debug("name set to ${result}")