// #importFile NONE
import com.collibra.dgc.core.api.dto.instance.asset.ChangeAssetRequest

PENDING_STATUS_ID = string2Uuid("00000000-0000-0000-0000-000000005023")

def changedAsset = assetApi.changeAsset(ChangeAssetRequest.builder()
       .id(item.id)
       .statusId(PENDING_STATUS_ID)
       .build())