{
  "metadata": {
    "name": "export-smoke"
  },
  "scripts": {
    "StartEvent_1": {
      "groovy": "println \"start\""
    }
  }
}