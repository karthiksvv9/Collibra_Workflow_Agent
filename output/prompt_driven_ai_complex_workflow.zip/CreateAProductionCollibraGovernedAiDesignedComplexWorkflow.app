{
  "appName": "Create A Production Collibra Governed Access And Policy",
  "forms": [
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowAccessRequestForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowRequesterReworkForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowStewardTriageForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowBusinessApprovalForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowComplianceReviewForm.form",
    "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowTechnicalRemediationForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflow.bpmn"
}