// #importFile NONE
import com.collibra.api.*
// Groovy script to send notification
// Assume process variables: requestId, status
// Placeholder for notification API call