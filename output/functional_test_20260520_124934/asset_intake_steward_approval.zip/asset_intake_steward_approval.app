{
  "description": "",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "AssetIntakeWorkflow",
          "type": "bpmn"
        },
        {
          "key": "assetRequestForm",
          "type": "form"
        },
        {
          "key": "assetValidationForm",
          "type": "form"
        },
        {
          "key": "stewardApprovalForm",
          "type": "form"
        }
      ]
    }
  },
  "flowApp": false,
  "groupsAccess": "",
  "icon": "glyphicon-asterisk",
  "key": "AssetIntakeWorkflowApp",
  "name": "Asset Intake and Approval Workflow",
  "paletteDefinitionCategory": "core",
  "theme": "theme-1",
  "url": "",
  "usersAccess": ""
}