// #importFile NONE
// Groovy script to send notification