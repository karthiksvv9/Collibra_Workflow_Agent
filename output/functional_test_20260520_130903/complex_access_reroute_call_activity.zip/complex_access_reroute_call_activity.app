{
  "description": "",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflow",
          "type": "bpmn"
        },
        {
          "key": "requestAccessForm",
          "type": "form"
        },
        {
          "key": "stewardTriageForm",
          "type": "form"
        },
        {
          "key": "businessApprovalForm",
          "type": "form"
        },
        {
          "key": "securityReviewForm",
          "type": "form"
        },
        {
          "key": "provisioningResultForm",
          "type": "form"
        },
        {
          "key": "notificationForm",
          "type": "form"
        }
      ]
    }
  },
  "flowApp": false,
  "groupsAccess": "",
  "icon": "glyphicon-asterisk",
  "key": "CreateAProductionCollibraGovernedAiDesignedComplexWorkflowApp",
  "name": "Complex Data Access Request Workflow",
  "paletteDefinitionCategory": "core",
  "theme": "theme-1",
  "url": "",
  "usersAccess": ""
}