// #importFile NONE
// Groovy script to validate request context and asset UUIDs
// Assume process variables: requestData, assetUUID, validationPassed
if (!validationPassed) {
  throw new Exception("Validation failed")
}