{
  "description": "",
  "extension": {
    "design": {
      "childModels": [
        {
          "key": "requestForm",
          "type": "form"
        },
        {
          "key": "approvalForm",
          "type": "form"
        },
        {
          "key": "RequestStewardReviewWorkflow",
          "type": "bpmn"
        }
      ]
    }
  },
  "flowApp": false,
  "groupsAccess": null,
  "icon": "glyphicon-asterisk",
  "key": "RequestStewardReviewWorkflowApp",
  "name": "Metadata Governance App",
  "paletteDefinitionCategory": "core",
  "theme": "theme-1",
  "url": null,
  "usersAccess": null
}