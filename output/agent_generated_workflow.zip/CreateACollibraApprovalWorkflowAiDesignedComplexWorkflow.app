{
  "appName": "Create A Collibra Approval Workflow With Requester Form",
  "forms": [
    "CreateACollibraApprovalWorkflowAiDesignedComplexWorkflowAccessRequestForm.form",
    "CreateACollibraApprovalWorkflowAiDesignedComplexWorkflowRequesterReworkForm.form",
    "CreateACollibraApprovalWorkflowAiDesignedComplexWorkflowStewardTriageForm.form",
    "CreateACollibraApprovalWorkflowAiDesignedComplexWorkflowBusinessApprovalForm.form",
    "CreateACollibraApprovalWorkflowAiDesignedComplexWorkflowComplianceReviewForm.form",
    "CreateACollibraApprovalWorkflowAiDesignedComplexWorkflowTechnicalRemediationForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "CreateACollibraApprovalWorkflowAiDesignedComplexWorkflow.bpmn"
}