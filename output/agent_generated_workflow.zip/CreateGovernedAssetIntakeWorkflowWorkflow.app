{
  "appName": "Create Governed Asset Intake Workflow With Steward Approval",
  "forms": [
    "CreateGovernedAssetIntakeWorkflowWorkflowStartForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "CreateGovernedAssetIntakeWorkflowWorkflow.bpmn"
}