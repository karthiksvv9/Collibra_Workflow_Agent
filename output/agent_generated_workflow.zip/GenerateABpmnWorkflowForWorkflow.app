{
  "appName": "Generate A Bpmn Workflow For Data Governance Asset",
  "forms": [
    "GenerateABpmnWorkflowForWorkflowStartForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "GenerateABpmnWorkflowForWorkflow.bpmn"
}