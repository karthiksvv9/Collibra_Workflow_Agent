{
  "appName": "Create A Complex Collibra Governed Access Workflow With",
  "forms": [
    "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowAccessRequestForm.form",
    "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowRequesterReworkForm.form",
    "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowStewardTriageForm.form",
    "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowBusinessApprovalForm.form",
    "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowComplianceReviewForm.form",
    "CreateAComplexCollibraGovernedAiDesignedComplexWorkflowTechnicalRemediationForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "CreateAComplexCollibraGovernedAiDesignedComplexWorkflow.bpmn"
}