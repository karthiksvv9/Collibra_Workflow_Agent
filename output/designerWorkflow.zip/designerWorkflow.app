{
  "appName": "Designer Workflow",
  "forms": [
    "requestForm.form"
  ],
  "generator": "DSC Collibra Workflow Automation Agent",
  "process": "designerWorkflow.bpmn"
}