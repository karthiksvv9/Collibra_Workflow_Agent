"""Core platform utilities."""

